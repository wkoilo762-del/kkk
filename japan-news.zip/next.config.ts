// next.config.ts
import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: false,
  },
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'picsum.photos', pathname: '/**' },
      { protocol: 'https', hostname: '*.googleusercontent.com', pathname: '/**' },
      { protocol: 'https', hostname: 'news.google.com', pathname: '/**' },
      { protocol: 'https', hostname: '*.yimg.jp', pathname: '/**' },
      { protocol: 'https', hostname: '*.nhk.or.jp', pathname: '/**' },
      { protocol: 'https', hostname: '*.nikkei.com', pathname: '/**' },
      { protocol: 'https', hostname: '*.microlink.io', pathname: '/**' },
      { protocol: 'https', hostname: 'api.microlink.io', pathname: '/**' },
      { protocol: 'https', hostname: 'image.thum.io', pathname: '/**' },
      { protocol: 'https', hostname: '*.wp.com', pathname: '/**' },
      { protocol: 'https', hostname: 's0.wp.com', pathname: '/**' },
    ],
  },
  output: 'standalone',
  transpilePackages: ['motion'],
};

export default nextConfig;