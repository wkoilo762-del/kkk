import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Genten Checker (原典チェッカー) - Japanese News Fact-Checking & Primary Source Verification',
  description:
    'Japanese news fact-checking and primary source verification tool. Identifies authentic mainstream articles, detects hyperbolic clickbait bias, and displays real newspaper evidence screenshots.',
  openGraph: {
    title: 'Genten Checker (原典チェッカー) - Japanese News Fact-Checking & Primary Source Verification',
    description:
      'Japanese news fact-checking and primary source verification tool. Identifies authentic mainstream articles, detects hyperbolic clickbait bias, and displays real newspaper evidence screenshots.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Genten Checker (原典チェッカー) - Japanese News Fact-Checking & Primary Source Verification',
    description:
      'Japanese news fact-checking and primary source verification tool. Identifies authentic mainstream articles, detects hyperbolic clickbait bias, and displays real newspaper evidence screenshots.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja" suppressHydrationWarning>
      <body suppressHydrationWarning className="bg-slate-950 text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
