// app/api/verify/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ai } from '@/lib/gemini';
import { extractSearchKeywords, fetchLiveJapaneseNewsRss } from '@/lib/rss';
import { extractSemanticSense } from '@/lib/sense';
import { fetchRealNewsMediaGallery, fetchRealSourceMedia } from '@/lib/newspaper';
import { CredibilityVerdict, GroundingSource, VerificationResult } from '@/lib/types';

export const maxDuration = 60;

const cache = new Map<string, { result: VerificationResult; timestamp: number }>();
const CACHE_TTL_MS = 15 * 60 * 1000;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { headline, lang = 'en' } = body;

    if (!headline || typeof headline !== 'string' || !headline.trim()) {
      return NextResponse.json(
        { error: lang === 'en' ? 'Headline is required' : '見出しが入力されていません' },
        { status: 400 }
      );
    }

    const trimmedHeadline = headline.trim();
    const isEnglish = lang === 'en';
    const cacheKey = `${trimmedHeadline}_${lang}`;

    const cached = cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
      return NextResponse.json(cached.result);
    }

    const semanticSense = await extractSemanticSense(trimmedHeadline);
    const { cleanTitle, removedSlang, searchQueries } = extractSearchKeywords(trimmedHeadline);

    // Harvest multi-outlet coverage (16+ articles across national papers & TV)
    const effectiveQuery = semanticSense.searchQueries[0] || searchQueries[0] || cleanTitle;
    const rssArticles = await fetchLiveJapaneseNewsRss(effectiveQuery, 16);

    const prompt = `あなたは日本国内ニュースの一次報道特定およびファクトチェックの専門家です。
以下の扇動的見出しについて、日本の信頼できる一次報道（Yahoo!ニュース、NHK、読売、朝日、毎日、産経、日経、TBS等）を特定し、正確に出力してください。
※YouTubeやSNSは一次報道から除外してください。

【見出し】: "${trimmedHeadline}"
【検索キーワード】: ${cleanTitle}

必ず以下のMarkdown形式で正確に出力してください：

【元記事・一次情報源】
記事見出し: (特定した一次報道の正確な見出し、なければ「信頼できる主要報道は確認できず」)
配信社: (NHK、朝日新聞、読売新聞、Yahoo!ニュース等の正式社名)
配信日時: (記事の配信日)
URL: (特定した正規URL)

【ファクトチェック・見出しとの差異】
・元記事の事実関係要約: (客観的事実の要約)
・見出しの煽り・バイアス分析: (誇張・歪曲の分析)
・判定: 【正確】 または 【誇張・切り取りあり】 または 【事実誤認】 または 【デマ・情報源なし】`;

    let responseText = '';
    const groundingSources: GroundingSource[] = [];

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          temperature: 0.1,
        },
      });

      responseText = response.text || '';

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      for (const chunk of chunks) {
        if (chunk.web?.uri && chunk.web?.title) {
          const uri = chunk.web.uri;
          if (!uri.includes('youtube.com') && !uri.includes('youtu.be')) {
            groundingSources.push({
              title: chunk.web.title,
              url: uri,
            });
          }
        }
      }
    } catch {
      // 429 / fallback
    }

    let articleTitle = '';
    let publisher = '';
    let publishDate = '';
    let parsedUrl = '';
    let factSummary = '';
    let biasAnalysis = '';
    let verdict: CredibilityVerdict = '誇張・切り取りあり';

    if (responseText) {
      const titleMatch = responseText.match(/記事見出し:\s*(.+)/);
      if (titleMatch) articleTitle = titleMatch[1].trim();

      const pubMatch = responseText.match(/配信社:\s*(.+)/);
      if (pubMatch) publisher = pubMatch[1].trim();

      const dateMatch = responseText.match(/配信日時:\s*(.+)/);
      if (dateMatch) publishDate = dateMatch[1].trim();

      const urlMatch = responseText.match(/URL:\s*(https?:\/\/[^\s\n)]+)/);
      if (urlMatch) parsedUrl = urlMatch[1].trim();

      const factMatch = responseText.match(/・元記事の事実関係要約:\s*([\s\S]*?)(?=・見出しの煽り|$)/);
      if (factMatch) factSummary = factMatch[1].trim();

      const biasMatch = responseText.match(/・見出しの煽り・バイアス分析:\s*([\s\S]*?)(?=・判定:|$)/);
      if (biasMatch) biasAnalysis = biasMatch[1].trim();

      if (responseText.includes('【正確】')) verdict = '正確';
      else if (responseText.includes('【事実誤認】')) verdict = '事実誤認';
      else if (responseText.includes('【デマ・情報源なし】')) verdict = 'デマ・情報源なし';
      else verdict = '誇張・切り取りあり';
    }

    // Disallow YouTube as primary publisher
    if (parsedUrl.includes('youtube.com') || parsedUrl.includes('youtu.be') || publisher.toLowerCase().includes('youtube')) {
      parsedUrl = '';
      publisher = '';
      articleTitle = '';
    }

    let bestUrl = parsedUrl;
    if (!bestUrl && groundingSources.length > 0) {
      bestUrl = groundingSources[0].url;
    }
    if (!bestUrl && rssArticles.length > 0) {
      bestUrl = rssArticles[0].link;
      if (!articleTitle) articleTitle = rssArticles[0].title;
      if (!publisher) publisher = rssArticles[0].source;
      if (!factSummary) factSummary = rssArticles[0].snippet || '';
    }

    const isNoSource =
      verdict === 'デマ・情報源なし' ||
      !bestUrl ||
      articleTitle.includes('確認できず');

    const primaryImageUrl = rssArticles[0]?.imageUrl;

    const realSourceMedia = !isNoSource && bestUrl
      ? await fetchRealSourceMedia({
          articleUrl: bestUrl,
          publisher: publisher || rssArticles[0]?.source || '主要報道機関',
          title: articleTitle || cleanTitle,
          fallbackImageUrl: primaryImageUrl,
        })
      : undefined;

    // Generates 15–20+ visual evidence screens across all outlets
    const realMediaGallery = !isNoSource
      ? await fetchRealNewsMediaGallery({
          primaryArticleUrl: bestUrl || '',
          primaryPublisher: publisher || rssArticles[0]?.source || '主要メディア',
          primaryTitle: articleTitle || cleanTitle,
          primaryImageUrl,
          rssArticles,
          semanticSubject: semanticSense.subject,
          semanticIncident: semanticSense.incident,
        })
      : [];

    const googleNewsSearchUrl = `https://news.google.com/search?q=${encodeURIComponent(effectiveQuery)}&hl=ja&gl=JP&ceid=JP:ja`;

    const result: VerificationResult = {
      rawMarkdown: responseText || `【元記事】\n記事見出し: ${articleTitle}\n配信社: ${publisher}\nURL: ${bestUrl}`,
      headline: trimmedHeadline,
      noiseRemovedHeadline: cleanTitle,
      removedNoiseWords: removedSlang,
      extractedEntities: [semanticSense.subject, semanticSense.incident].filter(Boolean),
      semanticSense,
      articleTitle: articleTitle || (isNoSource ? (isEnglish ? 'No credible reporting confirmed' : '信頼できる主要報道は確認できず') : cleanTitle),
      publisher: publisher || (isNoSource ? (isEnglish ? 'Unconfirmed' : '確認不可') : '主要メディア'),
      publishDate: publishDate || (isEnglish ? 'Recent' : '直近'),
      articleUrl: isNoSource ? '' : bestUrl,
      factSummary: factSummary || (isEnglish ? 'Objective reporting summary.' : '元記事の客観的報道要約。'),
      biasAnalysis: biasAnalysis || (isEnglish ? 'Bias and clickbait analysis.' : '見出しの煽り・バイアス分析。'),
      verdict,
      isNoSource,
      groundingSources,
      rssArticles,
      realSourceMedia,
      realMediaGallery,
      searchQuery: effectiveQuery,
      googleNewsSearchUrl,
      verifiedAt: new Date().toISOString(),
      lang: isEnglish ? 'en' : 'ja',
    };

    cache.set(cacheKey, { result, timestamp: Date.now() });

    return NextResponse.json(result);
  } catch (err: unknown) {
    console.error('Verify Route Fatal Error:', err);
    const errorMessage = err instanceof Error ? err.message : 'Verification failed';
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}