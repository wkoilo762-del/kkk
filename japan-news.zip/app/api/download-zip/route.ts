// app/api/download-zip/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createZipArchive, ZipFileEntry } from '@/lib/zip';

export const maxDuration = 60;

interface ItemToPack {
  url: string;
  filename: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const items: ItemToPack[] = body.items || [];
    const folderName = body.folderName || 'verified_news_evidence';

    if (items.length === 0) {
      return NextResponse.json({ error: 'No items to download' }, { status: 400 });
    }

    const filesToZip: ZipFileEntry[] = [];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let buffer: Buffer | null = null;

      if (item.url.startsWith('data:image/svg+xml')) {
        const svgContent = decodeURIComponent(item.url.replace(/^data:image\/svg\+xml;charset=utf-8,/, ''));
        buffer = Buffer.from(svgContent, 'utf-8');
      } else if (item.url.startsWith('http')) {
        try {
          const res = await fetch(item.url);
          if (res.ok) {
            buffer = Buffer.from(await res.arrayBuffer());
          }
        } catch {
          // ignore
        }
      }

      if (buffer) {
        filesToZip.push({
          name: `${folderName}/${item.filename}`,
          data: buffer,
        });
      }
    }

    const zipBuffer = createZipArchive(filesToZip);

    return new NextResponse(zipBuffer as unknown as BodyInit, {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${folderName}.zip"`,
      },
    });
  } catch (err) {
    console.error('ZIP Error:', err);
    return NextResponse.json({ error: 'ZIP generation failed' }, { status: 500 });
  }
}