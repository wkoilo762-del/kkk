// app/api/frame-image/route.ts
import { NextRequest, NextResponse } from 'next/server';
import sharp from 'sharp';

export const dynamic = 'force-dynamic';

async function fetchScreenshotBuffer(targetUrl: string, articleUrl?: string): Promise<Buffer> {
  const urlsToTry: string[] = [];

  if (targetUrl && targetUrl.startsWith('http')) {
    urlsToTry.push(targetUrl);
  }

  if (articleUrl && articleUrl.startsWith('http') && !articleUrl.includes('smartnews')) {
    urlsToTry.push(
      `https://s0.wp.com/mshots/v1/${encodeURIComponent(articleUrl)}?w=1280&h=1200`
    );
  }

  for (const url of urlsToTry) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 14000);

      const res = await fetch(url, {
        signal: controller.signal,
        redirect: 'follow',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        },
      });
      clearTimeout(timeout);

      if (res.ok) {
        const buffer = Buffer.from(await res.arrayBuffer());
        if (buffer.length > 4000) {
          return buffer;
        }
      }
    } catch {
      // try next
    }
  }

  return await sharp({
    create: {
      width: 1280,
      height: 600,
      channels: 3,
      background: '#ffffff',
    },
  })
    .jpeg()
    .toBuffer();
}

/**
 * Trims away empty white space from the bottom
 * and wraps the 3x Bold Yellow Border directly around the article text.
 */
export async function processArticleCapture(
  inputBuffer: Buffer,
  part: number = 1
): Promise<Buffer> {
  const BORDER = 24; // 3x Bold Yellow
  const TARGET_WIDTH = 1280;

  let targetBuffer = inputBuffer;

  try {
    const metadata = await sharp(inputBuffer).metadata();
    const rawWidth = metadata.width || TARGET_WIDTH;
    const rawHeight = metadata.height || 800;

    // Slice only if article is genuinely long
    if (rawHeight > 1200) {
      if (part === 1) {
        targetBuffer = await sharp(inputBuffer)
          .extract({ left: 0, top: 0, width: rawWidth, height: Math.floor(rawHeight * 0.55) })
          .toBuffer();
      } else {
        const topOffset = Math.floor(rawHeight * 0.45);
        targetBuffer = await sharp(inputBuffer)
          .extract({ left: 0, top: topOffset, width: rawWidth, height: rawHeight - topOffset })
          .toBuffer();
      }
    }

    // AUTOMATICALLY REMOVE BLANK WHITE SPACE FROM THE BOTTOM
    targetBuffer = await sharp(targetBuffer)
      .trim({ background: '#ffffff', threshold: 18 })
      .toBuffer();

    // Scale width cleanly to 1280px without adding any height padding or white space
    targetBuffer = await sharp(targetBuffer)
      .resize({ width: TARGET_WIDTH, withoutEnlargement: false })
      .toBuffer();
  } catch {
    targetBuffer = inputBuffer;
  }

  // Wrap the 3x Bold Yellow border directly around the trimmed content
  return await sharp(targetBuffer)
    .extend({
      top: BORDER,
      bottom: BORDER,
      left: BORDER,
      right: BORDER,
      background: '#facc15', // Pure 3X Bold Yellow
    })
    .jpeg({ quality: 92 })
    .toBuffer();
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const targetUrl = searchParams.get('url');
  const articleUrl = searchParams.get('articleUrl') || undefined;
  const part = parseInt(searchParams.get('part') || '1', 10);

  if (!targetUrl || !targetUrl.startsWith('http')) {
    return new NextResponse('Missing url parameter', { status: 400 });
  }

  try {
    const rawBuffer = await fetchScreenshotBuffer(targetUrl, articleUrl);
    const framedBuffer = await processArticleCapture(rawBuffer, part);

    return new NextResponse(framedBuffer as unknown as BodyInit, {
      headers: {
        'Content-Type': 'image/jpeg',
        'Cache-Control': 'public, max-age=86400, immutable',
      },
    });
  } catch (err) {
    console.error('Frame image error:', err);
    return new NextResponse('Failed to process image', { status: 500 });
  }
}