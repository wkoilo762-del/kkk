'use client';

import React, { useState, useEffect, useSyncExternalStore } from 'react';
import Header from '@/components/Header';
import HeadlineInput from '@/components/HeadlineInput';
import ProcessingStepper from '@/components/ProcessingStepper';
import VerificationResultView from '@/components/VerificationResultView';
import MediaGuideModal from '@/components/MediaGuideModal';
import HistoryDrawer from '@/components/HistoryDrawer';
import { VerificationResult } from '@/lib/types';
import { AppLanguage, translations } from '@/lib/translations';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Info,
  Clock,
  RotateCcw,
} from 'lucide-react';

function emptySubscribe() {
  return () => {};
}

function useIsMounted() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

function getStoredLang(): AppLanguage {
  try {
    const saved = localStorage.getItem('genten_checker_lang');
    return saved === 'ja' || saved === 'en' ? saved : 'en';
  } catch {
    return 'en';
  }
}

function getStoredHistory(): VerificationResult[] {
  try {
    const saved = localStorage.getItem('genten_checker_history');
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export default function Home() {
  const isMounted = useIsMounted();
  const [selectedLang, setSelectedLang] = useState<AppLanguage | null>(null);
  const lang: AppLanguage = selectedLang ?? (isMounted ? getStoredLang() : 'en');

  const [headline, setHeadline] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isQuotaError, setIsQuotaError] = useState(false);
  const [countdown, setCountdown] = useState<number>(0);
  const [result, setResult] = useState<VerificationResult | null>(null);

  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [historyOverride, setHistoryOverride] = useState<VerificationResult[] | null>(null);
  const history: VerificationResult[] = historyOverride ?? (isMounted ? getStoredHistory() : []);

  const t = translations[lang];

  const handleToggleLang = () => {
    const nextLang: AppLanguage = lang === 'en' ? 'ja' : 'en';
    setSelectedLang(nextLang);
    try {
      localStorage.setItem('genten_checker_lang', nextLang);
    } catch {
      // ignore
    }
  };

  // Countdown timer effect for rate-limit recovery
  useEffect(() => {
    if (countdown <= 0) return;
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [countdown]);

  const saveToHistory = (newResult: VerificationResult) => {
    try {
      const updated = [newResult, ...history.filter(h => h.headline !== newResult.headline)].slice(0, 30);
      setHistoryOverride(updated);
      localStorage.setItem('genten_checker_history', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleClearHistory = () => {
    setHistoryOverride([]);
    try {
      localStorage.removeItem('genten_checker_history');
    } catch {
      // ignore
    }
  };

  const handleVerify = async (textToVerify?: string) => {
    const targetText = textToVerify || headline;
    if (!targetText.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setIsQuotaError(false);
    setResult(null);

    try {
      const response = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          headline: targetText.trim(),
          lang,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 429 || data.isQuotaError) {
          setIsQuotaError(true);
          setCountdown(30);
        }
        throw new Error(data.error || 'Verification failed.');
      }

      setResult(data);
      saveToHistory(data);
    } catch (err: unknown) {
      console.error('Verification error:', err);
      let parsedMessage = lang === 'en'
        ? 'A problem occurred while verifying the primary source. Please try again.'
        : '元記事の特定中に問題が発生しました。しばらく待ってから再試行してください。';

      if (err instanceof Error) {
        try {
          const parsed = JSON.parse(err.message);
          if (parsed?.error?.code === 429 || parsed?.error?.status === 'RESOURCE_EXUSHAUSTED') {
            setIsQuotaError(true);
            setCountdown(30);
            parsedMessage = lang === 'en'
              ? 'Gemini API temporary rate limit reached (429: Quota Exceeded). Please wait ~30 seconds before retrying or click one of the demo samples.'
              : 'Google Gemini APIの無料利用枠（429: Rate Limit / Quota Exceeded）に達しました。30秒ほど待ってから再試行するか、下のお試しサンプル見出しをクリックしてください。';
          } else if (parsed?.error?.message) {
            parsedMessage = parsed.error.message;
          }
        } catch {
          if (err.message.includes('429') || err.message.includes('RESOURCE_EXHAUSTED')) {
            setIsQuotaError(true);
            setCountdown(30);
            parsedMessage = lang === 'en'
              ? 'Gemini API temporary rate limit reached (429: Quota Exceeded). Please wait ~30 seconds before retrying or click one of the demo samples.'
              : 'Google Gemini APIの無料利用枠（429: Rate Limit / Quota Exceeded）に達しました。30秒ほど待ってから再試行するか、下のお試しサンプル見出しをクリックしてください。';
          } else {
            parsedMessage = err.message;
          }
        }
      }

      setError(parsedMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Top Header */}
      <Header
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenGuide={() => setIsGuideOpen(true)}
        historyCount={isMounted ? history.length : 0}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-8 sm:space-y-10">
        {/* Hero Section */}
        <div className="text-center space-y-4 max-w-3xl mx-auto pt-2 sm:pt-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold tracking-wide shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{t.heroTag}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight sm:leading-tight">
            {t.heroTitle1}
            <br className="sm:hidden" />
            <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-cyan-300 bg-clip-text text-transparent ml-1 sm:ml-2">
              {t.heroTitle2}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-400 leading-relaxed max-w-2xl mx-auto">
            {t.heroDesc}
          </p>

          {/* Feature Badges */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 pt-2 text-xs text-slate-400">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              {t.badge1}
            </span>
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              {t.badge2}
            </span>
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              {t.badge3}
            </span>
          </div>
        </div>

        {/* Headline Input Card */}
        <section aria-label="Headline Input Form">
          <HeadlineInput
            headline={headline}
            setHeadline={setHeadline}
            onSubmit={(text) => handleVerify(text)}
            isLoading={isLoading}
            lang={lang}
          />
        </section>

        {/* Processing Stepper when loading */}
        {isLoading && (
          <section aria-label="Processing Status">
            <ProcessingStepper isLoading={isLoading} lang={lang} />
          </section>
        )}

        {/* Quota / Rate-limit alert */}
        {isQuotaError && (
          <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-sm space-y-3 animate-fade-in">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold text-amber-300 block text-base">
                    {t.quotaErrorTitle}
                  </strong>
                  <p className="text-xs text-amber-300/90 mt-1 leading-relaxed">
                    {t.quotaErrorDesc}
                    {countdown > 0 ? (
                      <span className="font-mono font-bold text-white bg-amber-950/80 px-2 py-0.5 rounded ml-1 border border-amber-500/30">
                        {t.quotaCountdownPrefix} {countdown} {t.quotaCountdownSuffix}
                      </span>
                    ) : (
                      <span className="text-emerald-400 font-bold ml-1">
                        {t.quotaReady}
                      </span>
                    )}
                  </p>
                </div>
              </div>

              <button
                onClick={() => handleVerify()}
                disabled={countdown > 0 || isLoading}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${
                  countdown > 0 || isLoading
                    ? 'bg-amber-950/50 text-amber-500/50 border border-amber-800/40 cursor-not-allowed'
                    : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20 active:scale-95'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.quotaRetryBtn}</span>
              </button>
            </div>
            <div className="text-[11px] text-amber-400/80 pt-1 border-t border-amber-500/20">
              {t.quotaHint}
            </div>
          </div>
        )}

        {/* Generic Error Alert (when not quota error) */}
        {error && !isQuotaError && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-start justify-between gap-3 animate-fade-in">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold block">
                  {lang === 'en' ? 'Verification Error' : '検証エラー'}
                </strong>
                <span>{error}</span>
              </div>
            </div>
            <button
              onClick={() => handleVerify()}
              className="px-3 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-medium border border-rose-500/30 transition-colors shrink-0"
            >
              {lang === 'en' ? 'Retry' : '再試行'}
            </button>
          </div>
        )}

        {/* Verification Result Display */}
        {result && (
          <section aria-label="Fact Check Verification Result" className="animate-fade-in">
            <VerificationResultView result={result} lang={lang} />
          </section>
        )}

        {/* Explanatory / Fact-checking Best Practices Section */}
        {!result && !isLoading && (
          <section className="mt-12 pt-8 border-t border-slate-800/80">
            <h2 className="text-base sm:text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Info className="w-4 h-4 text-blue-400" />
              <span>{t.principlesTitle}</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1.5">
                <span className="font-bold text-blue-300 block text-sm">
                  {t.principle1Title}
                </span>
                <p className="text-slate-400 leading-relaxed">
                  {t.principle1Desc}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1.5">
                <span className="font-bold text-cyan-300 block text-sm">
                  {t.principle2Title}
                </span>
                <p className="text-slate-400 leading-relaxed">
                  {t.principle2Desc}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1.5">
                <span className="font-bold text-indigo-300 block text-sm">
                  {t.principle3Title}
                </span>
                <p className="text-slate-400 leading-relaxed">
                  {t.principle3Desc}
                </p>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Media Guide Modal */}
      <MediaGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
        lang={lang}
      />

      {/* History Drawer */}
      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelect={(item) => setResult(item)}
        onClear={handleClearHistory}
        lang={lang}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 mt-16 text-center text-xs text-slate-500">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-slate-400">
              {t.brandName} ({t.brandSub})
            </span>
          </div>
          <p className="text-slate-500 text-[11px]">
            {t.footerSub}
          </p>
        </div>
      </footer>
    </div>
  );
}
