import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 text-slate-100 p-4 text-center">
      <h2 className="text-3xl font-bold mb-2">404 - ページが見つかりません</h2>
      <p className="text-slate-400 text-sm mb-6">
        お探しのページは存在しないか、移動した可能性があります。
      </p>
      <Link
        href="/"
        className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm transition-colors"
      >
        ホームへ戻る
      </Link>
    </div>
  );
}
