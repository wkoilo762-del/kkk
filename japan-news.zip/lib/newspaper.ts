// lib/newspaper.ts
import { RealNewsMediaItem, RealSourceMedia, RssArticle } from './types';

// Complete CSS hiding Yahoo (#yHeader, #sub), Asahi, Todai, and all Japanese news headers & ads
const HIDE_ALL_HEADERS_AND_CLUTTER = encodeURIComponent(`
  #yHeader, [id*="yHeader"], [class*="yHeader"], .yjm-header,
  header, #header, .header, .site-header, #site-header, .l-header, #masthead,
  nav, #nav, .nav, .menu, #menu, .gnav, #gnav, .global-nav, .navigation, .yjm-nav,
  #sub, .yjm-sub, aside, .sidebar, #sidebar, #secondary, .sub-content, .widget-area,
  .advertisement, .ads, [class*="banner"], [id*="banner"], [class*="Ad"], [id*="ad"],
  [class*="campaign"], [class*="app-banner"], [class*="promotion"],
  .app-lead, .sp-app-banner, [data-tracking*="header"], [data-ylk*="sec:header"] {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    max-height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
  }
  body, main, article, #main, .main, .content {
    margin: 0 !important;
    padding-top: 0 !important;
    padding-left: 16px !important;
    width: 100% !important;
    max-width: 100% !important;
  }
`);

export function generateArticleOnlyCaptureUrl(url: string, part: 1 | 2 = 1): string {
  if (!url || !url.startsWith('http')) return '';
  const cleanUrl = url.trim();

  if (part === 1) {
    // 5-second wait + H1 title target without any website header or Yahoo #yHeader
    return `https://api.microlink.io?url=${encodeURIComponent(
      cleanUrl
    )}&screenshot=true&waitForTimeout=5000&viewport.width=1280&viewport.height=1100&scrollTo=h1&styles=${HIDE_ALL_HEADERS_AND_CLUTTER}&meta=false&embed=screenshot.url`;
  }

  // Part 2: Continuation to last sentence
  return `https://api.microlink.io?url=${encodeURIComponent(
    cleanUrl
  )}&screenshot=true&waitForTimeout=5000&viewport.width=1280&viewport.height=1100&scrollTo=650&styles=${HIDE_ALL_HEADERS_AND_CLUTTER}&meta=false&embed=screenshot.url`;
}

export function generatePageScreenshotUrl(url: string, index = 0): string {
  if (!url || !url.startsWith('http')) return '';
  const cleanUrl = url.trim();

  if (index % 2 === 0) {
    return generateArticleOnlyCaptureUrl(cleanUrl, 1);
  }
  return `https://s0.wp.com/mshots/v1/${encodeURIComponent(cleanUrl)}?w=1280&h=800`;
}

export async function fetchRealSourceMedia(params: {
  articleUrl: string;
  publisher: string;
  title: string;
  fallbackImageUrl?: string;
}): Promise<RealSourceMedia | undefined> {
  const { articleUrl, publisher, title, fallbackImageUrl } = params;

  if (!articleUrl || articleUrl === 'なし' || !articleUrl.startsWith('http')) {
    return undefined;
  }

  const screenshotUrl = generateArticleOnlyCaptureUrl(articleUrl, 1);
  const part2ScreenshotUrl = generateArticleOnlyCaptureUrl(articleUrl, 2);

  return {
    articleUrl,
    publisher: publisher || '一次報道機関',
    title: title || '一次報道記事',
    screenshotUrl,
    part2ScreenshotUrl,
    isLongArticle: true,
    imageUrl: fallbackImageUrl,
  };
}

export async function fetchRealNewsMediaGallery(params: {
  primaryArticleUrl: string;
  primaryPublisher: string;
  primaryTitle: string;
  primaryImageUrl?: string;
  rssArticles: RssArticle[];
  semanticSubject: string;
  semanticIncident: string;
}): Promise<RealNewsMediaItem[]> {
  const {
    primaryArticleUrl,
    primaryPublisher,
    primaryTitle,
    primaryImageUrl,
    rssArticles,
    semanticSubject,
  } = params;

  const gallery: RealNewsMediaItem[] = [];
  const seenUrls = new Set<string>();

  if (primaryArticleUrl && primaryArticleUrl.startsWith('http')) {
    seenUrls.add(primaryArticleUrl);

    // Primary Part 1: H1 Title without header
    gallery.push({
      id: 'primary-part1',
      type: 'newspaper_screenshot',
      title: `${primaryTitle || semanticSubject} (Part 1: H1見出し〜本文)`,
      publisher: primaryPublisher || '主要報道機関',
      articleUrl: primaryArticleUrl,
      imageUrl: generateArticleOnlyCaptureUrl(primaryArticleUrl, 1),
      part: 1,
      caption: `【一次報道Part 1】${primaryPublisher} H1見出し〜本文前半`,
      badge: 'Part 1: H1見出し〜前半',
    });

    // Primary Part 2: Continuation to last sentence
    gallery.push({
      id: 'primary-part2',
      type: 'newspaper_screenshot',
      title: `${primaryTitle || semanticSubject} (Part 2: 本文後半〜最終文末尾)`,
      publisher: primaryPublisher || '主要報道機関',
      articleUrl: primaryArticleUrl,
      imageUrl: generateArticleOnlyCaptureUrl(primaryArticleUrl, 2),
      part: 2,
      caption: `【一次報道Part 2】${primaryPublisher} 本文続き〜記事末尾`,
      badge: 'Part 2: 後半〜末尾',
    });

    if (primaryImageUrl && primaryImageUrl.startsWith('http')) {
      gallery.push({
        id: 'primary-photo',
        type: 'article_photo',
        title: `${semanticSubject}の報道写真`,
        publisher: primaryPublisher || '主要報道機関',
        articleUrl: primaryArticleUrl,
        imageUrl: primaryImageUrl,
        caption: `【公式報道写真】${primaryPublisher}`,
        badge: '報道現場写真',
      });
    }
  }

  // Related multi-outlet articles
  rssArticles.forEach((article, idx) => {
    if (!article.link || seenUrls.has(article.link)) return;
    seenUrls.add(article.link);

    gallery.push({
      id: `outlet-p1-${idx}`,
      type: 'newspaper_screenshot',
      title: `${article.title} (Part 1)`,
      publisher: article.source || '主要メディア',
      articleUrl: article.link,
      imageUrl: generateArticleOnlyCaptureUrl(article.link, 1),
      part: 1,
      caption: `【${article.source}】H1見出し〜本文`,
      pubDate: article.pubDate,
      badge: `${article.source}`,
    });

    if (idx < 3) {
      gallery.push({
        id: `outlet-p2-${idx}`,
        type: 'newspaper_screenshot',
        title: `${article.title} (Part 2)`,
        publisher: article.source || '主要メディア',
        articleUrl: article.link,
        imageUrl: generateArticleOnlyCaptureUrl(article.link, 2),
        part: 2,
        caption: `【${article.source}】本文続き〜末尾`,
        pubDate: article.pubDate,
        badge: `${article.source} Part 2`,
      });
    }

    if (article.imageUrl && article.imageUrl.startsWith('http')) {
      gallery.push({
        id: `outlet-photo-${idx}`,
        type: 'article_photo',
        title: `${article.title} - 掲載写真`,
        publisher: article.source || '主要メディア',
        articleUrl: article.link,
        imageUrl: article.imageUrl,
        caption: `【報道現場写真】${article.source}`,
        pubDate: article.pubDate,
        badge: '報道写真',
      });
    }
  });

  return gallery;
}