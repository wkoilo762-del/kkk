// lib/articleCardSvg.ts

function escapeXml(unsafe: string): string {
  return (unsafe || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function wrapText(text: string, maxCharsPerLine = 15): string[] {
  const lines: string[] = [];
  let remaining = (text || '').trim();
  while (remaining.length > 0) {
    if (remaining.length <= maxCharsPerLine) {
      lines.push(remaining);
      break;
    }
    lines.push(remaining.slice(0, maxCharsPerLine));
    remaining = remaining.slice(maxCharsPerLine).trim();
  }
  return lines;
}

export function generateAttachmentCardSvg(params: {
  title: string;
  leadText: string;
  imageUrl?: string;
  publishDate: string;
  publisher: string;
  displayUrl: string;
  themeColor: string;
  hasYellowBorder?: boolean;
}): string {
  const {
    title,
    leadText,
    imageUrl,
    publishDate,
    publisher,
    displayUrl,
    themeColor = '#0077c8',
    hasYellowBorder = true,
  } = params;

  const titleLines = wrapText(title, 17).slice(0, 3);
  const leadLines = wrapText(leadText, 13).slice(0, 7);

  // Clean URL to fit the browser address pill
  const shortUrl = displayUrl.length > 34 ? displayUrl.slice(0, 31) + '...' : displayUrl;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 680" width="540" height="680">
  <defs>
    <clipPath id="imgClip">
      <rect x="24" y="240" width="180" height="150" rx="4" />
    </clipPath>
  </defs>

  <!-- Base Card Background -->
  <rect width="540" height="680" rx="14" fill="#ffffff" />
  ${hasYellowBorder ? `<rect x="0" y="0" width="540" height="680" rx="14" fill="none" stroke="#facc15" stroke-width="12" />` : ''}

  <!-- 1. Top Browser Chrome Bar -->
  <rect x="6" y="6" width="528" height="44" fill="#f1f3f4" rx="8" />

  <!-- Mac Window Dots -->
  <circle cx="28" cy="28" r="6" fill="#ff5f56" />
  <circle cx="46" cy="28" r="6" fill="#ffbd2e" />
  <circle cx="64" cy="28" r="6" fill="#27c93f" />

  <!-- Address Bar Pill -->
  <rect x="82" y="15" width="414" height="26" rx="13" fill="#ffffff" stroke="#dadce0" stroke-width="1" />
  <!-- Globe Icon -->
  <circle cx="100" cy="28" r="6" fill="none" stroke="#5f6368" stroke-width="1.2" />
  <line x1="94" y1="28" x2="106" y2="28" stroke="#5f6368" stroke-width="1.2" />
  <line x1="100" y1="22" x2="100" y2="34" stroke="#5f6368" stroke-width="1.2" />

  <!-- Clean Publisher URL Text -->
  <text x="114" y="32" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="12" fill="#5f6368">
    ${escapeXml(shortUrl)}
  </text>
  <!-- Pop-out icon -->
  <text x="474" y="32" font-family="sans-serif" font-size="12" fill="#70757a">↗</text>

  <!-- 2. Publisher Header Bar (Theme Color: NHK Blue, Yahoo Red, Asahi Navy, etc.) -->
  <rect x="6" y="50" width="528" height="48" fill="${themeColor}" />
  <text x="24" y="81" font-family="'Helvetica Neue', Arial, 'Hiragino Sans', sans-serif" font-size="20" font-weight="900" fill="#ffffff" letter-spacing="0.5">
    ${escapeXml(publisher)}
  </text>

  <!-- Clock icon -->
  <g transform="translate(492, 65)">
    <circle cx="10" cy="10" r="8" fill="none" stroke="#ffffff" stroke-width="1.5" />
    <polyline points="10,5 10,10 13,10" fill="none" stroke="#ffffff" stroke-width="1.5" />
  </g>

  <!-- 3. Article Date -->
  <text x="24" y="128" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="13" fill="#8c929c">
    ${escapeXml(publishDate)}
  </text>

  <!-- 4. Japanese Headline -->
  <g transform="translate(24, 156)">
    ${titleLines
      .map(
        (line, idx) =>
          `<text x="0" y="${idx * 28}" font-family="'Hiragino Kaku Gothic ProN', Meiryo, sans-serif" font-size="19" font-weight="800" fill="#111827">${escapeXml(line)}</text>`
      )
      .join('\n    ')}
  </g>

  <!-- 5. Two-Column Layout: Picture on Left + Article Text on Right -->
  <!-- Left: Real Photo -->
  ${
    imageUrl
      ? `<image href="${escapeXml(imageUrl)}" x="24" y="240" width="180" height="150" preserveAspectRatio="xMidYMid slice" clip-path="url(#imgClip)" />
         <rect x="24" y="240" width="180" height="150" fill="none" stroke="#e5e7eb" stroke-width="1" rx="4" />`
      : `<rect x="24" y="240" width="180" height="150" rx="4" fill="#f3f4f6" stroke="#e5e7eb" stroke-width="1" />`
  }

  <!-- Right: Japanese Article Body Text -->
  <g transform="translate(220, 256)">
    ${leadLines
      .map(
        (line, idx) =>
          `<text x="0" y="${idx * 20}" font-family="'Hiragino Kaku Gothic ProN', Meiryo, sans-serif" font-size="13" fill="#374151" font-weight="500">${escapeXml(line)}</text>`
      )
      .join('\n    ')}
  </g>

  <!-- 6. "■ 関連情報" (Related Information) Section with Skeleton Bars -->
  <g transform="translate(24, 435)">
    <rect x="0" y="-12" width="10" height="10" fill="#9ca3af" />
    <text x="18" y="-3" font-family="'Hiragino Kaku Gothic ProN', Meiryo, sans-serif" font-size="14" font-weight="bold" fill="#374151">
      関連情報
    </text>
    <rect x="0" y="16" width="480" height="7" rx="3" fill="#f3f4f6" />
    <rect x="0" y="32" width="440" height="7" rx="3" fill="#f3f4f6" />
    <rect x="0" y="48" width="380" height="7" rx="3" fill="#f3f4f6" />
  </g>

  <!-- 7. Footer: "元記事を開く ↗" -->
  <g transform="translate(24, 638)">
    <text x="0" y="0" font-family="'Hiragino Kaku Gothic ProN', Meiryo, sans-serif" font-size="14" font-weight="bold" fill="#374151">
      元記事を開く
    </text>
    <text x="96" y="-1" font-family="sans-serif" font-size="13" fill="#374151">↗</text>
  </g>
</svg>`;
}