// lib/sense.ts
import { SemanticSense } from '@/lib/types';

// Common institutional abbreviations and aliases in Japanese news
const ENTITY_ALIASES: Record<string, { full: string; short: string }> = {
  東大: { full: '東京大学', short: '東大' },
  京大: { full: '京都大学', short: '京大' },
  阪大: { full: '大阪大学', short: '阪大' },
  名大: { full: '名古屋大学', short: '名大' },
  東北大: { full: '東北大学', short: '東北大' },
  九大: { full: '九州大学', short: '九大' },
  北大: { full: '北海道大学', short: '北大' },
  早稲田: { full: '早稲田大学', short: '早稲田' },
  慶応: { full: '慶應義塾大学', short: '慶応' },
  明大: { full: '明治大学', short: '明大' },
  青学: { full: '青山学院大学', short: '青学' },
  トヨタ: { full: 'トヨタ自動車', short: 'トヨタ' },
  日産: { full: '日産自動車', short: '日産' },
  ホンダ: { full: '本田技研工業', short: 'ホンダ' },
  気象庁: { full: '気象庁', short: '気象庁' },
  金融庁: { full: '金融庁', short: '金融庁' },
  国税庁: { full: '国税庁', short: '国税庁' },
};

const TOPIC_NORMALIZATIONS: Record<string, { formal: string; short: string; en: string }> = {
  次期総長: { formal: '総長選考', short: '総長', en: 'Presidential Selection / Election' },
  総長問題: { formal: '総長選考', short: '総長', en: 'Presidential Selection / Election' },
  総長選: { formal: '総長選考', short: '総長', en: 'Presidential Selection / Election' },
  学長選: { formal: '学長選考', short: '学長', en: 'University President Selection' },
  総裁選: { formal: '自民党総裁選挙', short: '総裁選', en: 'LDP Presidential Election' },
  代表選: { formal: '代表選挙', short: '代表選', en: 'Party Leadership Election' },
  知事選: { formal: '知事選挙', short: '知事選', en: 'Gubernatorial Election' },
  EV全面撤退: { formal: 'EV戦略', short: 'EV', en: 'Electric Vehicle Business Strategy' },
  EV撤退: { formal: 'EV戦略', short: 'EV', en: 'Electric Vehicle Business Strategy' },
  闇バイト: { formal: '特殊詐欺', short: '受け子', en: 'Scam Cash Courier Investigation' },
  受け子: { formal: '特殊詐欺', short: '受け子', en: 'Scam Cash Courier Investigation' },
  預金口座: { formal: '金融所得課税', short: '預金課税', en: 'Bank Deposit Taxation' },
  自動課税: { formal: '金融所得課税', short: '預金課税', en: 'Bank Deposit Taxation' },
  富士山: { formal: '富士山火山防災', short: '富士山 噴火', en: 'Mt. Fuji Volcanic Activity' },
};

export function extractSenseHeuristic(headline: string): SemanticSense {
  let matchedEntity = { full: '', short: '' };
  for (const [key, val] of Object.entries(ENTITY_ALIASES)) {
    if (headline.includes(key) || (val.full && headline.includes(val.full))) {
      matchedEntity = val;
      break;
    }
  }

  let matchedTopic = { formal: '', short: '', en: '' };
  for (const [key, val] of Object.entries(TOPIC_NORMALIZATIONS)) {
    if (headline.includes(key)) {
      matchedTopic = val;
      break;
    }
  }

  const searchQueries: string[] = [];

  if (matchedEntity.full && matchedTopic.formal) {
    searchQueries.push(`${matchedEntity.full} ${matchedTopic.formal}`);
    searchQueries.push(`${matchedEntity.short} ${matchedTopic.short}`);
    searchQueries.push(`${matchedEntity.short} ${matchedTopic.formal}`);
  } else if (matchedEntity.short) {
    searchQueries.push(`${matchedEntity.short} ${matchedTopic.formal || ''}`.trim());
    searchQueries.push(`${matchedEntity.full} ${matchedTopic.formal || ''}`.trim());
  } else if (matchedTopic.formal) {
    searchQueries.push(`${matchedTopic.formal} 報道`);
  }

  // Strip slang & clickbait noise locally with 0 API tokens
  const cleanTitle = headline
    .replace(/[【】「」『』()[\]!?！？….]/g, ' ')
    .replace(/ｗｗｗ+|草+|大炎上|炎上しすぎて|炎上|オワタ|＼\(\^o\^\)／/g, ' ')
    .replace(/火に油を注ぐ|火に油を注いでしまう|火に油/g, ' ')
    .replace(/必死に釈明をするも|必死に釈明|必死に|釈明/g, ' 説明 ')
    .replace(/終了のお知らせ|完全に終わる|オワコン|日本滅亡へ/g, ' ')
    .replace(/焦り遂に|焦って|都合が悪くなり|都合が悪くなると/g, ' ')
    .replace(/大敗北|ボロ負け|完全論破|自爆/g, ' ')
    .replace(/緊急|速報|悲報|朗報|衝撃|驚愕/g, ' ')
    .replace(/([^\s]+)さん\b|([^\s]+)さん、/g, '$1 ')
    .replace(/\s+/g, ' ')
    .trim();

  searchQueries.push(cleanTitle);

  const subject = matchedEntity.full || matchedEntity.short || cleanTitle.split(' ')[0] || '対象組織・人物';
  const incident = matchedTopic.formal || cleanTitle.split(' ').slice(1, 3).join(' ') || '報道事象';
  const senseEnglish =
    matchedEntity.full && matchedTopic.en
      ? `${matchedEntity.full} - ${matchedTopic.en}`
      : 'Underlying news event';

  return {
    subject,
    incident,
    senseEnglish,
    searchQueries: Array.from(new Set(searchQueries.filter(Boolean))),
  };
}

/**
 * Fast, local semantic sense extraction that does not consume Gemini API quota.
 */
export async function extractSemanticSense(headline: string): Promise<SemanticSense> {
  return extractSenseHeuristic(headline);
}