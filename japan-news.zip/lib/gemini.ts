import { GoogleGenAI } from '@google/genai';

const apiKey = (process.env.GEMINI_API_KEY || '').trim();

export const isGeminiConfigured = Boolean(
  apiKey &&
  apiKey !== '' &&
  apiKey !== 'undefined' &&
  !apiKey.includes('TODO') &&
  !apiKey.includes('MY_GEMINI_API_KEY')
);

export const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});
