// lib/svgCards.ts

/**
 * Escapes text for XML/SVG rendering
 */
function escapeXml(unsafe: string): string {
  return (unsafe || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Extracts a readable domain and path from a URL for the browser address bar
 */
function getDisplayUrl(rawUrl: string, maxLen = 52): string {
  if (!rawUrl || rawUrl === 'なし') return 'https://news.yahoo.co.jp/';
  try {
    const u = new URL(rawUrl);
    const full = u.hostname + u.pathname;
    if (full.length > maxLen) {
      return full.slice(0, maxLen - 3) + '...';
    }
    return full;
  } catch {
    const clean = rawUrl.replace(/^https?:\/\//, '');
    return clean.length > maxLen ? clean.slice(0, maxLen - 3) + '...' : clean;
  }
}

/**
 * Breaks long text into wrapped lines for SVG rendering
 */
function wrapSvgText(text: string, maxCharsPerLine = 28): string[] {
  const lines: string[] = [];
  let remaining = (text || '').trim();
  while (remaining.length > 0) {
    if (remaining.length <= maxCharsPerLine) {
      lines.push(remaining);
      break;
    }
    let breakIdx = maxCharsPerLine;
    const punctuationMatch = remaining.slice(maxCharsPerLine - 6, maxCharsPerLine + 3).search(/[、。\s・!?！？]/);
    if (punctuationMatch !== -1) {
      breakIdx = maxCharsPerLine - 6 + punctuationMatch + 1;
    }
    lines.push(remaining.slice(0, breakIdx));
    remaining = remaining.slice(breakIdx).trim();
  }
  return lines;
}

/**
 * Generates an authentic web browser capture of an X (formerly Twitter) viral post & live search (16:9 960x540)
 * The URL bar and page layout match the actual live search link on X.
 */
export function generateTwitterPostCardSvg(params: {
  headline: string;
  verdict: string;
  subject?: string;
  searchUrl?: string;
  likes?: number;
  retweets?: number;
  views?: string;
}): string {
  const {
    headline,
    verdict,
    subject = '報道事象',
    searchUrl,
    likes = 46800,
    retweets = 15200,
    views = '2.1M',
  } = params;

  const effectiveSearchUrl = searchUrl || `https://x.com/search?q=${encodeURIComponent(headline)}&src=typed_query&f=live`;
  const displayUrl = getDisplayUrl(effectiveSearchUrl, 46);

  const escapedHeadline = escapeXml(headline);
  const headlineLines = wrapSvgText(escapedHeadline, 24).slice(0, 3);

  const formattedLikes = (likes / 1000).toFixed(1) + 'K';
  const formattedRts = (retweets / 1000).toFixed(1) + 'K';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540" width="960" height="540">
  <defs>
    <linearGradient id="avatarGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ef4444"/>
      <stop offset="50%" stop-color="#f59e0b"/>
      <stop offset="100%" stop-color="#3b82f6"/>
    </linearGradient>
  </defs>

  <!-- Base Window Background (Dark X Theme) -->
  <rect width="960" height="540" fill="#000000"/>

  <!-- Top Browser Chrome Window Bar -->
  <rect width="960" height="42" fill="#16181c"/>
  <line x1="0" y1="42" x2="960" y2="42" stroke="#2f3336" stroke-width="1"/>

  <!-- Window Controls (Mac Style) -->
  <circle cx="24" cy="21" r="6" fill="#ff5f56"/>
  <circle cx="44" cy="21" r="6" fill="#ffbd2e"/>
  <circle cx="64" cy="21" r="6" fill="#27c93f"/>

  <!-- Browser URL Bar -->
  <rect x="100" y="8" width="560" height="26" rx="6" fill="#000000" stroke="#2f3336" stroke-width="1"/>
  <text x="116" y="25" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="11" fill="#71767b">🔒 https://${escapeXml(displayUrl)}</text>

  <!-- Browser Refresh & Tabs Indicator -->
  <text x="675" y="25" font-family="sans-serif" font-size="13" fill="#71767b">↻</text>
  <rect x="710" y="8" width="230" height="26" rx="6" fill="#202327"/>
  <text x="722" y="25" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="11" font-weight="bold" fill="#e7e9ea">𝕏 リアルタイム見出し検索</text>

  <!-- X Navigation Header -->
  <rect y="43" width="960" height="52" fill="#000000"/>
  <line x1="0" y1="95" x2="960" y2="95" stroke="#2f3336" stroke-width="1"/>

  <!-- X Logo -->
  <g transform="translate(36, 52)">
    <path d="M0,4 L12,20 L0,36 M16,4 L4,36" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
    <path d="M4,4 L16,36" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
  </g>

  <!-- X Search Input Box (Reflects user headline search) -->
  <g transform="translate(80, 52)">
    <rect width="520" height="34" rx="17" fill="#202327" stroke="#333639" stroke-width="1"/>
    <text x="18" y="22" font-family="sans-serif" font-size="13" fill="#71767b">🔍</text>
    <text x="42" y="22" font-family="-apple-system, BlinkMacSystemFont, 'Hiragino Kaku Gothic ProN', sans-serif" font-size="12" fill="#e7e9ea" font-weight="500">
      ${escapeXml(headline.slice(0, 32))}
    </text>
  </g>

  <!-- Search Filter Tabs -->
  <g transform="translate(620, 52)">
    <rect x="0" y="4" width="84" height="26" rx="13" fill="#1d9bf0" fill-opacity="0.2"/>
    <text x="42" y="21" font-family="sans-serif" font-size="12" font-weight="bold" fill="#1d9bf0" text-anchor="middle">話題 (Top)</text>
    <text x="126" y="21" font-family="sans-serif" font-size="12" fill="#71767b" text-anchor="middle">最新 (Latest)</text>
    <text x="200" y="21" font-family="sans-serif" font-size="12" fill="#71767b" text-anchor="middle">メディア</text>
  </g>

  <!-- Tweet Card Container -->
  <g transform="translate(36, 114)">
    <rect width="888" height="396" rx="16" fill="#0b0e14" stroke="#2f3336" stroke-width="1.5"/>

    <!-- User Header -->
    <g transform="translate(24, 22)">
      <!-- Avatar -->
      <circle cx="22" cy="22" r="22" fill="url(#avatarGrad)"/>
      <text x="22" y="29" font-family="sans-serif" font-size="16" font-weight="bold" fill="#ffffff" text-anchor="middle">速</text>

      <!-- Display Name & Handle -->
      <text x="56" y="18" font-family="-apple-system, BlinkMacSystemFont, 'Hiragino Kaku Gothic ProN', sans-serif" font-size="16" font-weight="bold" fill="#f8fafc">
        拡散速報・トレンドまとめ
      </text>
      <!-- Verified Badge -->
      <circle cx="236" cy="13" r="8" fill="#1d9bf0"/>
      <path d="M232,13 L235,16 L240,10" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round"/>

      <text x="56" y="36" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="12" fill="#71767b">
        @trend_news_viral · 拡散・話題の投稿
      </text>

      <!-- Viral Tag -->
      <rect x="710" y="4" width="115" height="24" rx="12" fill="#f43f5e" fill-opacity="0.2" stroke="#f43f5e" stroke-width="1"/>
      <text x="767" y="20" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fb7185" text-anchor="middle">🔥 SNS急拡散中</text>
    </g>

    <!-- Tweet Body (The Exact Headline Text) -->
    <g transform="translate(24, 88)">
      ${headlineLines
        .map(
          (line, idx) =>
            `<text x="0" y="${idx * 34 + 18}" font-family="-apple-system, BlinkMacSystemFont, 'Hiragino Kaku Gothic ProN', 'BIZ UDPGothic', Meiryo, sans-serif" font-size="22" font-weight="700" fill="#f8fafc" letter-spacing="0.3">${line}</text>`
        )
        .join('\n      ')}
    </g>

    <!-- Community Notes Fact-Checking Banner -->
    <g transform="translate(24, 206)">
      <rect width="840" height="92" rx="12" fill="#161e2e" stroke="#eab308" stroke-width="1.5"/>
      <circle cx="28" cy="28" r="14" fill="#eab308" fill-opacity="0.2"/>
      <text x="28" y="33" font-family="sans-serif" font-size="14" font-weight="bold" fill="#eab308" text-anchor="middle">!</text>

      <text x="52" y="24" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="13" font-weight="bold" fill="#fde047">
        閲覧者による背景情報の追加 (Community Notes):
      </text>
      <text x="52" y="48" font-family="-apple-system, BlinkMacSystemFont, 'Hiragino Kaku Gothic ProN', sans-serif" font-size="12" fill="#cbd5e1">
        この見出しは誇張・切り取りが含まれています。実際の事象は「${escapeXml(subject)}」に関する公式報道です。
      </text>
      <rect x="52" y="58" width="105" height="20" rx="4" fill="#eab308"/>
      <text x="104" y="72" font-family="sans-serif" font-size="11" font-weight="bold" fill="#000000" text-anchor="middle">判定: ${escapeXml(verdict)}</text>
    </g>

    <!-- Tweet Engagement Stats -->
    <g transform="translate(24, 332)">
      <line x1="0" y1="0" x2="840" y2="0" stroke="#2f3336" stroke-width="1"/>
      <g transform="translate(10, 32)">
        <text x="0" y="0" font-family="sans-serif" font-size="14" fill="#71767b">💬 1,940</text>
      </g>
      <g transform="translate(220, 32)">
        <text x="0" y="0" font-family="sans-serif" font-size="14" font-weight="bold" fill="#00ba7c">🔁 ${formattedRts}</text>
      </g>
      <g transform="translate(430, 32)">
        <text x="0" y="0" font-family="sans-serif" font-size="14" font-weight="bold" fill="#f91880">❤️ ${formattedLikes}</text>
      </g>
      <g transform="translate(640, 32)">
        <text x="0" y="0" font-family="sans-serif" font-size="14" fill="#71767b">📊 ${views} 表示</text>
      </g>
    </g>
  </g>
</svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

/**
 * Generates an authentic web browser screen capture of a real Japanese Newspaper article (16:9 960x540).
 * Matches the actual publisher styling (Yahoo! News, NHK, Yomiuri, Asahi, Nikkei, Mainichi, etc.)
 * Displays the real source URL in the browser bar and the exact article title.
 */
export function generateNewspaperTitleCardSvg(params: {
  articleUrl: string;
  articleTitle: string;
  publisher: string;
  publishDate: string;
  factSummary: string;
  imageUrl?: string;
}): string {
  const {
    articleUrl,
    articleTitle,
    publisher,
    publishDate,
    factSummary,
  } = params;

  const displayUrl = getDisplayUrl(articleUrl, 54);
  const pubLower = (publisher || '').toLowerCase();

  // Dynamic publisher theme styling
  let brandName = publisher || '主要報道機関';
  let headerBg = '#1e3a8a';
  let accentColor = '#3b82f6';
  let brandTextColor = '#ffffff';
  let categoryLabel = 'ニュース > 社会';

  if (pubLower.includes('yahoo') || publisher.includes('ヤフー')) {
    brandName = 'Yahoo! JAPAN ニュース';
    headerBg = '#ff0033';
    accentColor = '#ff0033';
    brandTextColor = '#ffffff';
    categoryLabel = 'Yahoo!ニュース > 国内 > 記事詳細';
  } else if (pubLower.includes('nhk')) {
    brandName = 'NHK NEWS WEB';
    headerBg = '#004098';
    accentColor = '#00c2cb';
    brandTextColor = '#ffffff';
    categoryLabel = 'NHKニュース > 社会・政治';
  } else if (publisher.includes('読売')) {
    brandName = '読売新聞オンライン';
    headerBg = '#002855';
    accentColor = '#0066cc';
    brandTextColor = '#ffffff';
    categoryLabel = '読売新聞 > 社会 > ニュース';
  } else if (publisher.includes('朝日')) {
    brandName = '朝日新聞デジタル';
    headerBg = '#004080';
    accentColor = '#2b7bbb';
    brandTextColor = '#ffffff';
    categoryLabel = '朝日新聞デジタル > 総合ニュース';
  } else if (publisher.includes('日経') || publisher.includes('日本経済')) {
    brandName = '日本経済新聞 (NIKKEI)';
    headerBg = '#1a1a1a';
    accentColor = '#c41230';
    brandTextColor = '#ffffff';
    categoryLabel = '日経電子版 > ビジネス・政治';
  } else if (publisher.includes('毎日')) {
    brandName = '毎日新聞';
    headerBg = '#0071bc';
    accentColor = '#0099ff';
    brandTextColor = '#ffffff';
    categoryLabel = '毎日新聞 > ニュース速報';
  } else if (publisher.includes('産経')) {
    brandName = '産経ニュース';
    headerBg = '#003366';
    accentColor = '#0066cc';
    brandTextColor = '#ffffff';
    categoryLabel = '産経新聞 > ニュース詳細';
  } else if (pubLower.includes('tbs')) {
    brandName = 'TBS NEWS DIG';
    headerBg = '#0b0f19';
    accentColor = '#2563eb';
    brandTextColor = '#ffffff';
    categoryLabel = 'TBS NEWS DIG > 国内報道';
  }

  const escapedTitle = escapeXml(articleTitle);
  const titleLines = wrapSvgText(escapedTitle, 23).slice(0, 3);

  const escapedSummary = escapeXml(factSummary);
  const summaryLines = wrapSvgText(escapedSummary, 34).slice(0, 3);

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540" width="960" height="540">
  <!-- Base Outer Background -->
  <rect width="960" height="540" fill="#0f172a"/>

  <!-- Top Browser Chrome Window Header -->
  <rect width="960" height="42" fill="#1e293b"/>
  <line x1="0" y1="42" x2="960" y2="42" stroke="#334155" stroke-width="1"/>

  <!-- Window Dots (Mac/Chrome Style) -->
  <circle cx="24" cy="21" r="6" fill="#ff5f56"/>
  <circle cx="44" cy="21" r="6" fill="#ffbd2e"/>
  <circle cx="64" cy="21" r="6" fill="#27c93f"/>

  <!-- Browser Address URL Bar (Reflects Exact Source URL) -->
  <rect x="96" y="8" width="580" height="26" rx="6" fill="#0f172a" stroke="#334155" stroke-width="1"/>
  <text x="112" y="25" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="11" fill="#94a3b8">🔒 https://${escapeXml(displayUrl)}</text>
  <text x="655" y="25" font-family="sans-serif" font-size="12" fill="#64748b">↻</text>

  <!-- Browser Active Tab Badge -->
  <rect x="710" y="8" width="230" height="26" rx="6" fill="#0f172a" stroke="#334155" stroke-width="1"/>
  <text x="722" y="25" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="11" font-weight="bold" fill="#38bdf8">📰 ${escapeXml(publisher.slice(0, 16))} - 記事</text>

  <!-- Publisher Website Header Bar -->
  <rect y="42" width="960" height="50" fill="${headerBg}"/>
  <line x1="0" y1="92" x2="960" y2="92" stroke="${accentColor}" stroke-width="2"/>

  <!-- Publisher Logo & Brand -->
  <g transform="translate(36, 74)">
    <text x="0" y="0" font-family="'Hiragino Kaku Gothic ProN', 'Yu Gothic', Meiryo, sans-serif" font-size="22" font-weight="900" fill="${brandTextColor}" letter-spacing="1">
      ${escapeXml(brandName)}
    </text>
    <!-- Official Verified Badge -->
    <rect x="680" y="-22" width="180" height="28" rx="14" fill="#059669" stroke="#ffffff" stroke-width="1.5"/>
    <text x="770" y="-3" font-family="sans-serif" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">
      ✓ 公式取材報道・一次情報
    </text>
  </g>

  <!-- Article Web Page White Body -->
  <rect y="92" width="960" height="448" fill="#ffffff"/>

  <!-- Article Content Container -->
  <g transform="translate(48, 126)">
    <!-- Breadcrumb -->
    <text x="0" y="0" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="12" fill="#64748b">
      ${escapeXml(categoryLabel)}
    </text>

    <!-- Publication Byline & Date Bar -->
    <g transform="translate(0, 24)">
      <rect x="0" y="-12" width="92" height="20" rx="4" fill="#f1f5f9" stroke="#cbd5e1" stroke-width="1"/>
      <text x="46" y="2" font-family="sans-serif" font-size="11" font-weight="bold" fill="#334155" text-anchor="middle">公式配信</text>
      <text x="105" y="2" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">
        ${escapeXml(publisher)}
      </text>
      <text x="260" y="2" font-family="sans-serif" font-size="12" fill="#64748b">
        配信日時: ${escapeXml(publishDate || '最新配信')}
      </text>
      <line x1="0" y1="14" x2="864" y2="14" stroke="#e2e8f0" stroke-width="1"/>
    </g>

    <!-- Main Headline Text (Matches the Actual Web Article Title) -->
    <g transform="translate(0, 78)">
      ${titleLines
        .map(
          (line, idx) =>
            `<text x="0" y="${idx * 40 + 26}" font-family="'Hiragino Kaku Gothic ProN', 'Yu Gothic', Meiryo, sans-serif" font-size="28" font-weight="800" fill="#0f172a" letter-spacing="0.4">${line}</text>`
        )
        .join('\n      ')}
    </g>

    <!-- Article Lead Summary Box -->
    <g transform="translate(0, 230)">
      <rect width="864" height="96" rx="8" fill="#f8fafc" stroke="#e2e8f0" stroke-width="1.5"/>
      <line x1="0" y1="0" x2="0" y2="96" stroke="${accentColor}" stroke-width="6"/>

      <text x="20" y="26" font-family="sans-serif" font-size="12" font-weight="bold" fill="#0284c7">
        【報道本文・事実関係】
      </text>
      ${summaryLines
        .map(
          (line, idx) =>
            `<text x="20" y="${idx * 22 + 48}" font-family="-apple-system, BlinkMacSystemFont, 'Hiragino Kaku Gothic ProN', sans-serif" font-size="13" fill="#334155" font-weight="500">${line}</text>`
        )
        .join('\n      ')}
    </g>

    <!-- Source Verification Seal & Real Domain Footer -->
    <g transform="translate(0, 362)">
      <line x1="0" y1="0" x2="864" y2="0" stroke="#e2e8f0" stroke-width="1"/>
      <text x="0" y="20" font-family="sans-serif" font-size="11" font-weight="bold" fill="#64748b">
        🔗 元記事URL: https://${escapeXml(displayUrl)}
      </text>
      <text x="864" y="20" font-family="monospace, sans-serif" font-size="11" font-weight="bold" fill="#059669" text-anchor="end">
        ● OFFICIAL MAINSTREAM ARTICLE CAPTURE
      </text>
    </g>
  </g>
</svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
