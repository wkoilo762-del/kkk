// lib/translations.ts

export type AppLanguage = 'ja' | 'en';

export interface Translations {
  brandName: string;
  brandBadge: string;
  brandSub: string;
  mediaGuideBtn: string;
  historyBtn: string;
  heroTag: string;
  heroTitle1: string;
  heroTitle2: string;
  heroDesc: string;
  badge1: string;
  badge2: string;
  badge3: string;
  inputLabel: string;
  pasteBtn: string;
  clearBtn: string;
  placeholder: string;
  charCount: string;
  shortcutHint: string;
  submitBtn: string;
  submittingBtn: string;
  presetHeader: string;
  tryThis: string;
  step1Title: string;
  step1Desc: string;
  step2Title: string;
  step2Desc: string;
  step3Title: string;
  step3Desc: string;
  step4Title: string;
  step4Desc: string;
  pipelineTitle: string;
  processing: string;
  done: string;
  quotaErrorTitle: string;
  quotaErrorDesc: string;
  quotaCountdownPrefix: string;
  quotaCountdownSuffix: string;
  quotaReady: string;
  quotaRetryBtn: string;
  quotaHint: string;
  principlesTitle: string;
  principle1Title: string;
  principle1Desc: string;
  principle2Title: string;
  principle2Desc: string;
  principle3Title: string;
  principle3Desc: string;
  footerSub: string;
  modalTitle: string;
  modalMissionLabel: string;
  modalMissionText: string;
  closeBtn: string;
  historyTitle: string;
  clearHistoryBtn: string;
  historyEmpty: string;
  historyEmptySub: string;
  viewDetail: string;
  verdictTitle: string;
  tabVisual: string;
  tabMarkdown: string;
  copiedBtn: string;
  senseCardTitle: string;
  senseSubLabel: string;
  senseSubjectLabel: string;
  senseIncidentLabel: string;
  senseEnglishLabel: string;
  noiseSectionTitle: string;
  removedNoiseLabel: string;
  noNoise: string;
  extractedEntitiesLabel: string;
  primarySourceTitle: string;
  activeLinkBadge: string;
  articleTitleLabel: string;
  publisherLabel: string;
  publishDateLabel: string;
  articleUrlLabel: string;
  noSourceAlert: string;
  copiedUrlBtn: string;
  copyUrlBtn: string;
  newspaperSectionTitle: string;
  realMediaNotice: string;
  realArticleImageTitle: string;
  inspectImage: string;
  diffSectionTitle: string;
  inputBoxTitle: string;
  inputBoxSub: string;
  factBoxTitle: string;
  factBoxSub: string;
  biasLabel: string;
  rssSectionTitle: string;
  rssSectionDesc: string;
  rssOpenGoogleNews: string;
  copyFormattedBtn: string;
  verifiedAtLabel: string;
  gallerySectionTitle: string;
  gallerySectionDesc: string;
  filterAll: string;
  filterScreenshots: string;
  filterPhotos: string;
  viewFullResolution: string;
  counterBadge: string;
  openArticleLink: string;
  totalItemsLabel: string;
}

export const translations: Record<AppLanguage, Translations> = {
  ja: {
    brandName: '原典チェッカー',
    brandBadge: '日本国内ニュース専用',
    brandSub: '一次情報特定＆信憑性検証エンジン',
    mediaGuideBtn: 'メディア判定ガイド',
    historyBtn: '履歴',
    heroTag: 'AI × リアルタイム一次報道照合',
    heroTitle1: 'ネットの煽り見出しから、',
    heroTitle2: '「元の事実」を即時特定。',
    heroDesc: 'SNSやまとめサイトの煽り・切り取り見出しから脱扇動化を行い、Yahoo!ニュース・NHK・全国紙等の一次報道・事実関係を特定してファクトチェックします。',
    badge1: '100%実在の一次報道のみ特定',
    badge2: '脱・煽り見出し処理',
    badge3: '信憑性4段階明瞭判定',
    inputLabel: '検証したいニュース見出し・まとめ記事タイトルを入力',
    pasteBtn: '貼り付け',
    clearBtn: 'クリア',
    placeholder: '例: 【悲報】〇〇氏、親族が闇バイト受け子で逮捕され都合悪くなり逃亡ｗｗｗ大炎上オワタ',
    charCount: '文字',
    shortcutHint: 'で即時検証',
    submitBtn: '一次情報・元記事を特定する',
    submittingBtn: '一次報道を特定中...',
    presetHeader: 'お試し見出しサンプル（クリックで即検証）',
    tryThis: 'この見出しを検証',
    step1Title: '脱・扇動化（ノイズ除去）',
    step1Desc: 'ネットスラングや煽り表現を取り除き、文脈の本質を抽出',
    step2Title: '主語・事象のエンティティ特定',
    step2Desc: '対象となる人物・企業・公的機関と具体的な出来事を同定',
    step3Title: '一次報道アーカイブ照合',
    step3Desc: '全国紙・NHK・通信社・Yahoo!ニュース等の実在記事を探索',
    step4Title: '事実照合・バイアス判定',
    step4Desc: '元記事の客観的事実と煽り見出しの乖離度を判定中',
    pipelineTitle: 'リアルタイム検証パイプライン実行中',
    processing: '解析中',
    done: '完了',
    quotaErrorTitle: 'API利用枠の一時制限',
    quotaErrorDesc: 'Google Gemini APIの無料レートリミットに達しました。自動復旧までお待ちください。',
    quotaCountdownPrefix: '残り',
    quotaCountdownSuffix: '秒',
    quotaReady: '再試行可能です',
    quotaRetryBtn: '今すぐ再試行',
    quotaHint: '※連続検証時は少し間隔を空けてご利用ください。',
    principlesTitle: '当エンジンの検証原則',
    principle1Title: '一次報道最優先',
    principle1Desc: 'まとめサイトやSNSの伝聞ではなく、全国紙・NHK・通信社・公的発表のみを拠り所とします。',
    principle2Title: '脱・感情的バイアス',
    principle2Desc: '「ｗｗｗ」「オワタ」「激怒」などの感情語を除去し、何が客観的事実であるかを切り分けます。',
    principle3Title: '実在リンク保証',
    principle3Desc: 'AIによるURL捏造を防ぎ、実在する報道アーカイブのみを証拠として提示します。',
    footerSub: '一次情報特定＆ファクトチェック検証エンジン • 日本国内ニュース専用',
    modalTitle: '信頼性の高い一次情報源の判定基準',
    modalMissionLabel: 'ミッション',
    modalMissionText: 'ネット上に溢れる扇動的・感情的なまとめ見出しに惑わされず、誰もが数秒で一次報道（元記事）と客観的事実にアクセスできる社会を目指しています。',
    closeBtn: '閉じる',
    historyTitle: '検証履歴',
    clearHistoryBtn: '全消去',
    historyEmpty: '検証履歴はありません',
    historyEmptySub: '見出しを検証するとここに保存されます。',
    viewDetail: '詳細を見る',
    verdictTitle: '信憑性判定',
    tabVisual: 'ビジュアル解析',
    tabMarkdown: 'Markdown出力',
    copiedBtn: 'コピー完了！',
    senseCardTitle: '文脈抽出エンジン (Sense-First Extraction)',
    senseSubLabel: '表層スラングの奥にある「実際の出来事」を把握',
    senseSubjectLabel: '対象組織・人物:',
    senseIncidentLabel: '実際の中核事象:',
    senseEnglishLabel: '文脈要約:',
    noiseSectionTitle: '脱・扇動化（ノイズ除去結果）',
    removedNoiseLabel: '除去されたスラング・感情語:',
    noNoise: 'スラングや過度な修飾語は検出されませんでした',
    extractedEntitiesLabel: '抽出されたエンティティ:',
    primarySourceTitle: '元記事・一次情報源',
    activeLinkBadge: '実在報道リンク確認済',
    articleTitleLabel: '特定された元記事タイトル',
    publisherLabel: '報道機関 / 掲載元:',
    publishDateLabel: '報道日時:',
    articleUrlLabel: '元記事 URL',
    noSourceAlert: '主要メディアによる信頼できる報道は確認できませんでした。ネット上の流言の可能性があります。',
    copiedUrlBtn: 'URLコピー完了',
    copyUrlBtn: 'URLをコピー',
    newspaperSectionTitle: '実在Web紙面記録 (Real Media Capture)',
    realMediaNotice: '※AI画像生成ではなく、実在記事ページのWeb紙面キャプチャです。',
    realArticleImageTitle: '元記事の掲載報道写真',
    inspectImage: '拡大表示',
    diffSectionTitle: 'ファクトチェック（事実関係の照合と乖離）',
    inputBoxTitle: '入力された見出しの主張',
    inputBoxSub: '※SNS・まとめサイトで拡散されている見出し',
    factBoxTitle: '一次報道の客観的事実',
    factBoxSub: '※主要報道機関が客観的に報じた内容',
    biasLabel: 'バイアス・煽り・誇張の分析',
    rssSectionTitle: '関連する主要一次報道 (実在リンク一覧)',
    rssSectionDesc: '日本の主要全国紙・通信社・NHK・Yahoo!ニュース等の最新配信',
    rssOpenGoogleNews: 'Google ニュースで全件確認',
    copyFormattedBtn: '検証レポートをコピー',
    verifiedAtLabel: '検証日時:',
    gallerySectionTitle: '実在報道紙面＆メディア証拠ギャラリー',
    gallerySectionDesc: '日本の主要全国紙、NHK、通信社等の実在Web紙面キャプチャおよび記事掲載写真',
    filterAll: 'すべて表示',
    filterScreenshots: 'Web紙面・記事キャプチャ',
    filterPhotos: '記事掲載報道写真',
    viewFullResolution: '拡大して紙面・見出しを読む',
    counterBadge: '点の実在報道メディアを特定・読み込み済',
    openArticleLink: '元記事ページを開く',
    totalItemsLabel: '点の実在紙面・写真',
  },
  en: {
    brandName: 'Genten Checker',
    brandBadge: 'Japan Domestic News',
    brandSub: 'Primary Source Identification & Fact-Check Engine',
    mediaGuideBtn: 'Source Criteria',
    historyBtn: 'History',
    heroTag: 'AI × Real-time Primary News Grounding',
    heroTitle1: 'From sensationalized internet clickbait,',
    heroTitle2: 'trace the objective original facts.',
    heroDesc: 'Strip sensationalism, slang, and clickbait from social media headlines to identify verified primary reporting from Yahoo! News, NHK, and Japan’s national dailies.',
    badge1: '100% Real Primary Sources',
    badge2: 'Clickbait & Noise Stripping',
    badge3: 'Clear 4-Tier Credibility Verdict',
    inputLabel: 'Enter Japanese news headline, matome blog title, or SNS claim',
    pasteBtn: 'Paste',
    clearBtn: 'Clear',
    placeholder: 'e.g. 【悲報】小川淳也氏、親族が闇バイト受け子で逮捕され都合悪くなり逃亡ｗｗｗ大炎上オワタ',
    charCount: 'chars',
    shortcutHint: 'to verify immediately',
    submitBtn: 'Identify Primary Sources',
    submittingBtn: 'Identifying primary reporting...',
    presetHeader: 'Demo Headline Samples (Click to test)',
    tryThis: 'Test This Headline',
    step1Title: 'Noise Removal (De-sensationalization)',
    step1Desc: 'Stripping slang, emojis, and emotional drama to reveal the core event',
    step2Title: 'Entity & Action Extraction',
    step2Desc: 'Pinpointing proper nouns, organizations, and real-world incidents',
    step3Title: 'Primary Source Grounding',
    step3Desc: 'Cross-referencing live databases of Japan’s national dailies, NHK, and wires',
    step4Title: 'Fact Matching & Verdict',
    step4Desc: 'Comparing objective reporting with headline exaggerations',
    pipelineTitle: 'Verification Pipeline in Progress',
    processing: 'Processing',
    done: 'Done',
    quotaErrorTitle: 'Temporary API Rate Limit Reached',
    quotaErrorDesc: 'Google Gemini API free tier limit (429) hit. Please wait a moment for automatic recovery.',
    quotaCountdownPrefix: 'Retry in',
    quotaCountdownSuffix: 's',
    quotaReady: 'Ready to retry',
    quotaRetryBtn: 'Retry Now',
    quotaHint: 'Tip: Please space out requests slightly when verifying multiple headlines.',
    principlesTitle: 'Fact-Checking Principles',
    principle1Title: 'Primary Reporting First',
    principle1Desc: 'We prioritize verified reporting from NHK, major national dailies, wire agencies, and official government releases.',
    principle2Title: 'De-sensationalization',
    principle2Desc: 'We remove emotional bait words ("www", "over", "epic fail") to isolate verifiable factual claims.',
    principle3Title: 'No Fake URLs',
    principle3Desc: 'All source links and web captures correspond to real news articles, preventing hallucinated 404 links.',
    footerSub: 'Primary Source Identification & Fact-Check Engine • Japan Domestic News',
    modalTitle: 'Credible Primary Source Criteria',
    modalMissionLabel: 'Mission',
    modalMissionText: 'Empowering readers to immediately verify sensationalized internet claims against reputable, objective Japanese primary journalism.',
    closeBtn: 'Close',
    historyTitle: 'Verification History',
    clearHistoryBtn: 'Clear All',
    historyEmpty: 'No verification history yet',
    historyEmptySub: 'Verified headlines will appear here.',
    viewDetail: 'View Details',
    verdictTitle: 'Credibility Verdict',
    tabVisual: 'Visual Report',
    tabMarkdown: 'Raw Markdown',
    copiedBtn: 'Copied!',
    senseCardTitle: 'Context Extraction Engine (Sense-First)',
    senseSubLabel: 'Identifies the real-world event beneath internet metaphors and slang',
    senseSubjectLabel: 'Target Entity:',
    senseIncidentLabel: 'Core Incident:',
    senseEnglishLabel: 'Context Summary:',
    noiseSectionTitle: 'De-sensationalization (Noise Removed)',
    removedNoiseLabel: 'Removed Slang & Buzzwords:',
    noNoise: 'No sensational buzzwords detected in headline',
    extractedEntitiesLabel: 'Extracted Entities:',
    primarySourceTitle: 'Primary Source & Original Article',
    activeLinkBadge: 'Verified Live Source Link',
    articleTitleLabel: 'Identified Original Article Title',
    publisherLabel: 'Publisher / Outlet:',
    publishDateLabel: 'Publish Date:',
    articleUrlLabel: 'Original Article URL',
    noSourceAlert: 'No credible mainstream reporting confirmed. Likely an unverified internet rumor or hoax.',
    copiedUrlBtn: 'URL Copied',
    copyUrlBtn: 'Copy URL',
    newspaperSectionTitle: 'Authentic Webpage Capture (Real Media)',
    realMediaNotice: 'Note: Live webpage screenshot of the genuine publisher article (100% real, non-AI).',
    realArticleImageTitle: 'Official Article Press Photography',
    inspectImage: 'Inspect Full Image',
    diffSectionTitle: 'Fact Check (Objective Facts vs Headline Claim)',
    inputBoxTitle: 'Claim in Sensationalized Headline',
    inputBoxSub: 'Headline as circulated on SNS / Matome blogs',
    factBoxTitle: 'Verified Objective Facts',
    factBoxSub: 'Facts confirmed by mainstream Japanese journalism',
    biasLabel: 'Sensationalism & Bias Analysis',
    rssSectionTitle: 'Related Live Primary Coverage (Active Links)',
    rssSectionDesc: 'Live coverage from Japanese national dailies, NHK, wires, and Yahoo! News',
    rssOpenGoogleNews: 'Open Full Results in Google News',
    copyFormattedBtn: 'Copy Verification Report',
    verifiedAtLabel: 'Verified At:',
    gallerySectionTitle: 'Authentic Newspaper & Media Evidence Gallery',
    gallerySectionDesc: 'Live webpage screenshots and press photography from Japan’s national newspapers and NHK.',
    filterAll: 'All Media',
    filterScreenshots: 'Webpage Captures',
    filterPhotos: 'Press Photos',
    viewFullResolution: 'Enlarge to read headline text',
    counterBadge: 'Real Media Assets Loaded',
    openArticleLink: 'Open Original Article',
    totalItemsLabel: 'Real Newspaper & Photo Assets',
  },
};