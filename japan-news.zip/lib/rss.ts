// lib/rss.ts
import { RssArticle } from './types';

export function extractSearchKeywords(headline: string): {
  cleanTitle: string;
  searchQueries: string[];
  removedSlang: string[];
} {
  const slangPatterns = [
    /ｗｗｗ+/g,
    /草+/g,
    /【悲報】|【朗報】|【速報】|【驚愕】|【激怒】|【悲痛】|【終焉】|【閲覧注意】|【衝撃】|【緊急】/g,
    /大炎上|大炎上中|炎上/g,
    /逝く|オワタ|＼\(\^o\^\)\／/g,
    /発狂|ブチギレ|激怒/g,
    /終了のお知らせ|完全に終わる|オワコン|日本滅亡へ/g,
    /焦り遂に|焦って|都合が悪くなり|都合が悪くなると/g,
    /大敗北|ボロ負け|完全論破/g,
    /！？|！！|\?{2,}|\!{2,}/g,
    /ヤバすぎる|ガチで|マジで|とんでもない/g,
    /逃亡|トンズラ|逆ギレ/g,
  ];

  const removedSlang: string[] = [];
  let cleaned = headline;

  for (const pattern of slangPatterns) {
    const matches = headline.match(pattern);
    if (matches) {
      matches.forEach((m) => {
        if (!removedSlang.includes(m)) {
          removedSlang.push(m);
        }
      });
      cleaned = cleaned.replace(pattern, ' ');
    }
  }

  cleaned = cleaned.replace(/[【】「」『』()[\]!?！？]/g, ' ').replace(/\s+/g, ' ').trim();

  const segmented = cleaned
    .replace(/([A-Za-z0-9]+)/g, ' $1 ')
    .replace(/自動車|株式会社|代表|幹事長|議員|容疑者/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const tokens = segmented
    .split(/[、。\s,._/／・\-でをにがのはとへからよりされ]+/g)
    .map((t) => t.trim())
    .filter(
      (t) =>
        t.length >= 2 &&
        !['これ', 'それ', 'あれ', 'について', 'など', 'だが', 'けど', '決定', 'する', 'した', '生える', 'なる', '氏'].includes(t)
    );

  const queries: string[] = [];
  if (tokens.length >= 2) {
    queries.push(`${tokens[0]} ${tokens[1]}`);
  }
  if (tokens.length >= 3) {
    queries.push(`${tokens[0]} ${tokens[1]} ${tokens[2]}`);
  }
  if (tokens.length > 0) {
    queries.push(tokens[0]);
  }
  queries.push(cleaned);

  return {
    cleanTitle: cleaned,
    searchQueries: Array.from(new Set(queries.filter(Boolean))),
    removedSlang,
  };
}

export async function resolveRealDestinationUrl(googleUrl: string): Promise<string> {
  if (!googleUrl || !googleUrl.includes('news.google.com')) {
    return googleUrl;
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);

    const res = await fetch(googleUrl, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml',
      },
      cache: 'no-store',
    });
    clearTimeout(timeout);

    if (res.url && !res.url.includes('news.google.com')) {
      return res.url;
    }

    const html = await res.text();
    const metaMatch = html.match(/<meta[^>]*http-equiv=["']refresh["'][^>]*content=["'][^"']*url=([^"']+)["']/i);
    if (metaMatch && metaMatch[1] && metaMatch[1].startsWith('http')) {
      return metaMatch[1];
    }

    const anchorMatch = html.match(/<a[^>]*href=["'](https?:\/\/(?!news\.google)[^"']+)["']/i);
    if (anchorMatch && anchorMatch[1]) {
      return anchorMatch[1];
    }
  } catch {
    // ignore
  }

  return googleUrl;
}

export async function fetchArticleImage(link: string): Promise<string | undefined> {
  if (
    link.includes('youtube.com') ||
    link.includes('youtu.be') ||
    link.includes('twitter.com') ||
    link.includes('x.com') ||
    link.includes('smartnews')
  ) {
    return undefined;
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);

    const res = await fetch(link, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml',
      },
      cache: 'no-store',
    });
    clearTimeout(timeout);

    if (!res.ok) return undefined;

    const html = await res.text();
    const match =
      html.match(/<meta[^>]*property=["']og:image["'][^>]*content=["']([^"']+)["']/i) ||
      html.match(/<meta[^>]*content=["']([^"']+)["'][^>]*property=["']og:image["']/i);

    if (match && match[1] && match[1].startsWith('http')) {
      const imgUrl = match[1];
      if (
        imgUrl.includes('googleusercontent.com') ||
        imgUrl.includes('google.com') ||
        imgUrl.includes('gstatic.com') ||
        imgUrl.includes('logo') ||
        imgUrl.includes('icon') ||
        imgUrl.includes('favicon')
      ) {
        return undefined;
      }
      return imgUrl;
    }

    return undefined;
  } catch {
    return undefined;
  }
}

/**
 * Harvests authentic articles across reliable news publishers (no 404s, no SmartNews)
 */
export async function fetchMultiOutletNews(query: string, maxItems = 16): Promise<RssArticle[]> {
  const articles: RssArticle[] = [];
  const seenUrls = new Set<string>();

  const queriesToRun = [
    query,
    `${query} NHK OR 読売 OR 朝日 OR 毎日 OR 産経`,
    `${query} TBS OR FNN OR 日テレ`,
  ];

  for (const q of queriesToRun) {
    if (articles.length >= maxItems) break;

    try {
      const encoded = encodeURIComponent(q);
      const url = `https://news.google.com/rss/search?q=${encoded}&hl=ja&gl=JP&ceid=JP:ja`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4500);

      const res = await fetch(url, {
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          Accept: 'application/rss+xml, application/xml, text/xml',
        },
        cache: 'no-store',
      });
      clearTimeout(timeout);

      if (!res.ok) continue;

      const xml = await res.text();
      const itemMatches = xml.match(/<item>([\s\S]*?)<\/item>/g) || [];

      for (const itemXml of itemMatches) {
        const rawTitle = (itemXml.match(/<title>([\s\S]*?)<\/title>/) || [])[1] || '';
        const rawLink = (itemXml.match(/<link>([\s\S]*?)<\/link>/) || [])[1] || '';
        const rawPubDate = (itemXml.match(/<pubDate>([\s\S]*?)<\/pubDate>/) || [])[1] || '';
        const rawSource = (itemXml.match(/<source[^>]*>([\s\S]*?)<\/source>/) || [])[1] || '';
        const rawDesc = (itemXml.match(/<description>([\s\S]*?)<\/description>/) || [])[1] || '';

        const cleanTitle = rawTitle
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&#39;/g, "'");

        let publisher = rawSource.trim();
        if (!publisher && cleanTitle.includes(' - ')) {
          const parts = cleanTitle.split(' - ');
          publisher = parts[parts.length - 1];
        }

        const pubLower = publisher.toLowerCase();
        const linkLower = rawLink.toLowerCase();

        // STRICT FILTER: Block YouTube, social media, and SmartNews/aggregators that 404
        if (
          pubLower.includes('youtube') ||
          linkLower.includes('youtube.com') ||
          linkLower.includes('youtu.be') ||
          linkLower.includes('smartnews') ||
          linkLower.includes('gunosy') ||
          linkLower.includes('twitter.com') ||
          linkLower.includes('x.com') ||
          pubLower.includes('スマートニュース')
        ) {
          continue;
        }

        if (seenUrls.has(rawLink)) continue;
        seenUrls.add(rawLink);

        let formattedDate = rawPubDate;
        try {
          const d = new Date(rawPubDate);
          if (!isNaN(d.getTime())) {
            formattedDate = d.toLocaleString('ja-JP', {
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit',
            });
          }
        } catch {
          // fallback
        }

        const cleanSnippet = rawDesc
          .replace(/<[^>]+>/g, ' ')
          .replace(/&nbsp;/g, ' ')
          .replace(/&amp;/g, '&')
          .replace(/\s+/g, ' ')
          .trim();

        articles.push({
          title: cleanTitle,
          link: rawLink,
          pubDate: formattedDate,
          source: publisher || '主要報道機関',
          snippet: cleanSnippet || undefined,
        });

        if (articles.length >= maxItems) break;
      }
    } catch {
      // continue next
    }
  }

  // Resolve real canonical destination URLs for top 10 articles
  const targetSlice = articles.slice(0, 10);
  await Promise.allSettled(
    targetSlice.map(async (article) => {
      const realUrl = await resolveRealDestinationUrl(article.link);
      // If resolved URL is a broken SmartNews or 404 domain, revert
      if (!realUrl.includes('smartnews')) {
        article.link = realUrl;
      }
      const img = await fetchArticleImage(realUrl);
      if (img) {
        article.imageUrl = img;
      }
    })
  );

  return articles;
}

export async function fetchLiveJapaneseNewsRss(query: string, maxItems = 16): Promise<RssArticle[]> {
  return fetchMultiOutletNews(query, maxItems);
}