// lib/types.ts

export type CredibilityVerdict = 
  | '正確'
  | '誇張・切り取りあり'
  | '事実誤認'
  | 'デマ・情報源なし';

export interface GroundingSource {
  title: string;
  url: string;
}

export interface NewsImageSource {
  url: string;
  caption?: string;
  publisher: string;
  sourceUrl: string;
  isAuthentic: boolean;
}

export interface NewspaperScreenshotData {
  publisher: string;
  date: string;
  edition: string;
  headline: string;
  subheadline?: string;
  leadParagraph: string;
  mainImageUrl?: string;
  imageCaption?: string;
  articleUrl: string;
  paperType: 'yomiuri' | 'asahi' | 'nikkei' | 'mainichi' | 'sankei' | 'nhk' | 'general';
}

export interface RssArticle {
  title: string;
  link: string;
  pubDate: string;
  source: string;
  snippet?: string;
  imageUrl?: string;
}

export interface SemanticSense {
  subject: string;
  incident: string;
  senseEnglish: string;
  searchQueries: string[];
}

export interface RealSourceMedia {
  articleUrl: string;
  publisher: string;
  title: string;
  screenshotUrl?: string;        // Part 1: Headline (Title) to middle
  part2ScreenshotUrl?: string;   // Part 2: Middle to last word of article
  isLongArticle?: boolean;
  imageUrl?: string;
}

export interface RealNewsMediaItem {
  id: string;
  type: 'newspaper_screenshot' | 'article_photo';
  title: string;
  publisher: string;
  articleUrl: string;
  imageUrl: string;
  part?: 1 | 2;
  caption?: string;
  pubDate?: string;
  badge?: string;
}

export interface VerificationResult {
  rawMarkdown: string;
  headline: string;
  noiseRemovedHeadline?: string;
  removedNoiseWords: string[];
  extractedEntities: string[];
  semanticSense?: SemanticSense;
  articleTitle: string;
  publisher: string;
  publishDate: string;
  articleUrl: string;
  factSummary: string;
  biasAnalysis: string;
  verdict: CredibilityVerdict;
  isNoSource: boolean;
  groundingSources: GroundingSource[];
  rssArticles?: RssArticle[];
  newsImages?: NewsImageSource[];
  newspaperSnapshot?: NewspaperScreenshotData;
  realSourceMedia?: RealSourceMedia;
  realMediaGallery?: RealNewsMediaItem[];
  searchQuery?: string;
  googleNewsSearchUrl?: string;
  verifiedAt: string;
  lang?: 'ja' | 'en';
}

export interface VerificationRequest {
  headline: string;
  lang?: 'ja' | 'en';
}