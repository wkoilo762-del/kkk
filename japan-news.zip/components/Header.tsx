'use client';

import React from 'react';
import { ShieldCheck, BookOpen, Languages } from 'lucide-react';
import { AppLanguage, translations } from '@/lib/translations';

interface HeaderProps {
  lang: AppLanguage;
  onToggleLang: () => void;
  onOpenGuide: () => void;
  historyCount: number;
  onOpenHistory: () => void;
}

export default function Header({
  lang,
  onToggleLang,
  onOpenGuide,
  historyCount,
  onOpenHistory,
}: HeaderProps) {
  const t = translations[lang];

  return (
    <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40 transition-colors">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20 text-white">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-slate-100 tracking-tight">
                {t.brandName}
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                {t.brandBadge}
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              {t.brandSub}
            </p>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Switcher */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-800/90 hover:bg-slate-700 border border-slate-700 rounded-lg transition-all shadow-xs"
            title={lang === 'ja' ? 'Switch to English' : '日本語に切り替え'}
          >
            <Languages className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono uppercase">{lang === 'ja' ? 'English' : '日本語'}</span>
          </button>

          <button
            onClick={onOpenGuide}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-all"
          >
            <BookOpen className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">{t.mediaGuideBtn}</span>
            <span className="sm:hidden">ガイド</span>
          </button>

          <button
            onClick={onOpenHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-all relative"
          >
            <span>{t.historyBtn}</span>
            {historyCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[11px] font-bold flex items-center justify-center">
                {historyCount > 9 ? '9+' : historyCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
