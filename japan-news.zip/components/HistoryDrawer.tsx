'use client';

import React from 'react';
import { X, Trash2, Clock, ChevronRight } from 'lucide-react';
import { VerificationResult, CredibilityVerdict } from '@/lib/types';
import { AppLanguage, translations } from '@/lib/translations';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: VerificationResult[];
  onSelect: (item: VerificationResult) => void;
  onClear: () => void;
  lang: AppLanguage;
}

export default function HistoryDrawer({
  isOpen,
  onClose,
  history,
  onSelect,
  onClear,
  lang,
}: HistoryDrawerProps) {
  if (!isOpen) return null;
  const t = translations[lang];

  const getVerdictBadge = (verdict: CredibilityVerdict) => {
    switch (verdict) {
      case '正確':
        return {
          style: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          text: lang === 'en' ? 'Accurate' : '正確',
        };
      case '誇張・切り取りあり':
        return {
          style: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
          text: lang === 'en' ? 'Exaggerated' : '誇張・切り取りあり',
        };
      case '事実誤認':
        return {
          style: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
          text: lang === 'en' ? 'Incorrect' : '事実誤認',
        };
      case 'デマ・情報源なし':
      default:
        return {
          style: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
          text: lang === 'en' ? 'Hoax / No Source' : 'デマ・情報源なし',
        };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col h-full animate-slide-left">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-white text-sm sm:text-base">
              {t.historyTitle} ({history.length})
            </h3>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={onClear}
                className="text-slate-400 hover:text-rose-400 text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-800 transition-colors"
                title={lang === 'en' ? 'Clear all history' : '全履歴を消去'}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.clearHistoryBtn}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {history.length === 0 ? (
            <div className="text-center py-16 text-slate-500 text-xs space-y-2">
              <Clock className="w-8 h-8 mx-auto text-slate-700" />
              <p>{t.historyEmpty}</p>
              <p className="text-[11px] text-slate-600">
                {t.historyEmptySub}
              </p>
            </div>
          ) : (
            history.map((item, idx) => {
              const badge = getVerdictBadge(item.verdict);
              return (
                <div
                  key={idx}
                  onClick={() => {
                    onSelect(item);
                    onClose();
                  }}
                  className="p-3.5 rounded-xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 hover:border-blue-500/50 cursor-pointer transition-all group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badge.style}`}
                      >
                        {badge.text}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono" suppressHydrationWarning>
                        {item.verifiedAt
                          ? new Date(item.verifiedAt).toLocaleDateString(
                              lang === 'en' ? 'en-US' : 'ja-JP'
                            )
                          : ''}
                      </span>
                    </div>

                    <p className="text-xs text-slate-200 font-medium line-clamp-2 group-hover:text-white transition-colors">
                      {item.headline}
                    </p>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="truncate max-w-[200px]">
                      {lang === 'en' ? 'Source: ' : '元記事: '}
                      {item.publisher || (lang === 'en' ? 'Unverified' : '未確認')}
                    </span>
                    <span className="text-blue-400 flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                      {t.viewDetail} <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
