'use client';

import React from 'react';
import { X, ShieldCheck, Newspaper, CheckCircle2 } from 'lucide-react';
import { AppLanguage, translations } from '@/lib/translations';

interface MediaGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: AppLanguage;
}

export default function MediaGuideModal({ isOpen, onClose, lang }: MediaGuideModalProps) {
  if (!isOpen) return null;
  const t = translations[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-white text-base">
              {t.modalTitle}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300">
          {/* Mission */}
          <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs sm:text-sm text-blue-200 leading-relaxed">
            <span className="font-bold text-white block mb-1">
              {t.modalMissionLabel}
            </span>
            {t.modalMissionText}
          </div>

          {/* Trusted Primary Sources Priority */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Newspaper className="w-4 h-4 text-blue-400" />
              <span>
                {lang === 'en'
                  ? 'Prioritized Japanese Mainstream Media (Japan Domestic Only)'
                  : '最優先する信頼性の高い主要メディア (Japan Only)'}
              </span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-white block mb-1">
                  {lang === 'en' ? 'News Portal & Public Broadcaster' : 'ポータル・公共放送'}
                </span>
                <ul className="space-y-1 text-slate-400">
                  <li>• Yahoo! ニュース (news.yahoo.co.jp)</li>
                  <li>• NHK (nhk.or.jp)</li>
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-white block mb-1">
                  {lang === 'en' ? 'Wire Services (News Agencies)' : '通信社'}
                </span>
                <ul className="space-y-1 text-slate-400">
                  <li>• 共同通信 (47news.jp / Kyodo News)</li>
                  <li>• 時事通信 (jiji.com / Jiji Press)</li>
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-white block mb-1">
                  {lang === 'en' ? '5 Major National Dailies' : '主要5大全国紙'}
                </span>
                <ul className="space-y-1 text-slate-400">
                  <li>• 読売新聞 (yomiuri.co.jp)</li>
                  <li>• 朝日新聞 (asahi.com)</li>
                  <li>• 毎日新聞 (mainichi.jp)</li>
                  <li>• 日本経済新聞 (nikkei.com)</li>
                  <li>• 産経新聞 (sankei.com)</li>
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-white block mb-1">
                  {lang === 'en' ? 'Key TV Networks & Official Statements' : '主要テレビ局・公式発表'}
                </span>
                <ul className="space-y-1 text-slate-400">
                  <li>• 日テレNEWS / テレ朝news</li>
                  <li>• TBS NEWS DIG / フジテレビ (FNN)</li>
                  <li>• 各省庁・公的機関・自治体発表</li>
                </ul>
              </div>
            </div>
          </div>

          {/* 4-Step Pipeline */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'en' ? '4-Stage Verification Workflow' : '4段階の検証パイプライン'}</span>
            </h4>

            <ol className="space-y-2 text-xs text-slate-300">
              <li className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 font-bold text-[10px]">
                  1
                </span>
                <div>
                  <strong className="text-white">
                    {lang === 'en' ? 'Noise Removal (De-sensationalization): ' : '脱・扇動化: '}
                  </strong>
                  {lang === 'en'
                    ? 'Strips internet slang such as "ｗｗｗ", "草", "大炎上", "悲報", "オワタ", and emotional buzzwords.'
                    : '「ｗｗｗ」「草」「大炎上」「悲報」「朗報」「逝く」「発狂」「終了のお知らせ」「焦り遂に」「大敗北」などのスラング・感情的修飾子を除去。'}
                </div>
              </li>
              <li className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 font-bold text-[10px]">
                  2
                </span>
                <div>
                  <strong className="text-white">
                    {lang === 'en' ? 'Entity & Action Extraction: ' : 'エンティティ＆アクション抽出: '}
                  </strong>
                  {lang === 'en'
                    ? 'Identifies proper nouns (people, parties, agencies), core incidents, and actions.'
                    : '固有名詞（人物・政党・企業・容疑者）＋ 中核となる事象 ＋ キーアクションを特定。'}
                </div>
              </li>
              <li className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 font-bold text-[10px]">
                  3
                </span>
                <div>
                  <strong className="text-white">
                    {lang === 'en' ? 'Google Search Grounding: ' : 'Google 検索の実行: '}
                  </strong>
                  {lang === 'en'
                    ? 'Searches credible primary reporting across Japanese mainstream publishers to locate grounded URLs.'
                    : '信頼できる一次報道記事を探索し、実在する正規URLを特定（架空URLの出力は厳禁）。'}
                </div>
              </li>
              <li className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 font-bold text-[10px]">
                  4
                </span>
                <div>
                  <strong className="text-white">
                    {lang === 'en' ? 'Fact Matching & Verdict: ' : '照合・検証・信憑性判定: '}
                  </strong>
                  {lang === 'en'
                    ? 'Compares verified facts with headline claims to assign clear verdicts: Accurate, Exaggerated, Incorrect, or Hoax.'
                    : '元記事の客観的事実と入力見出しの主張を対比し、「正確」「誇張・切り取りあり」「事実誤認」「デマ・情報源なし」を明瞭判定。'}
                </div>
              </li>
            </ol>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
}
