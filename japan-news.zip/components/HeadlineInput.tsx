// components/HeadlineInput.tsx
'use client';

import React from 'react';
import { Search, Sparkles, Clipboard, X } from 'lucide-react';
import { AppLanguage, translations } from '@/lib/translations';

interface HeadlineInputProps {
  headline: string;
  setHeadline: (text: string) => void;
  onSubmit: (textToSubmit?: string) => void;
  isLoading: boolean;
  lang: AppLanguage;
}

export default function HeadlineInput({
  headline,
  setHeadline,
  onSubmit,
  isLoading,
  lang,
}: HeadlineInputProps) {
  const t = translations[lang];

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setHeadline(text);
      }
    } catch {
      // Clipboard access may be restricted
    }
  };

  const handleClear = () => {
    setHeadline('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      if (headline.trim() && !isLoading) {
        onSubmit();
      }
    }
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute -top-24 -right-24 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-3">
          <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Search className="w-4 h-4 text-blue-400" />
            <span>{t.inputLabel}</span>
          </label>
          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={handlePaste}
              className="text-slate-400 hover:text-slate-200 flex items-center gap-1 transition-colors px-2 py-1 rounded hover:bg-slate-800"
              title="Paste from clipboard"
            >
              <Clipboard className="w-3.5 h-3.5" />
              <span>{t.pasteBtn}</span>
            </button>
            {headline && (
              <button
                type="button"
                onClick={handleClear}
                className="text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors px-2 py-1 rounded hover:bg-slate-800"
                title="Clear input"
              >
                <X className="w-3.5 h-3.5" />
                <span>{t.clearBtn}</span>
              </button>
            )}
          </div>
        </div>

        {/* Text Area */}
        <div className="relative">
          <textarea
            value={headline}
            onChange={(e) => setHeadline(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
            placeholder={t.placeholder}
            className="w-full h-32 sm:h-28 bg-slate-950/80 border border-slate-700/80 rounded-xl p-4 text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm sm:text-base leading-relaxed resize-none transition-all disabled:opacity-50"
          />

          <div className="absolute bottom-3 right-3 flex items-center gap-3">
            <span className="text-xs text-slate-500 font-mono">
              {headline.length} {t.charCount}
            </span>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[11px] text-slate-300">
              Ctrl + Enter
            </span>
            <span>{t.shortcutHint}</span>
          </div>

          <button
            type="button"
            onClick={() => onSubmit()}
            disabled={!headline.trim() || isLoading}
            className={`px-6 py-3 rounded-xl font-semibold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg transition-all ${
              !headline.trim() || isLoading
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white shadow-blue-500/25 hover:shadow-blue-500/40 active:scale-[0.99]'
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>{t.submittingBtn}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-cyan-300" />
                <span>{t.submitBtn}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}