'use client';

import React, { useEffect, useState } from 'react';
import { Filter, Search, Newspaper, CheckCircle2 } from 'lucide-react';
import { AppLanguage, translations } from '@/lib/translations';

interface ProcessingStepperProps {
  isLoading: boolean;
  lang: AppLanguage;
}

export default function ProcessingStepper({ isLoading, lang }: ProcessingStepperProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const t = translations[lang];

  const steps = [
    {
      title: t.step1Title,
      desc: t.step1Desc,
      icon: Filter,
    },
    {
      title: t.step2Title,
      desc: t.step2Desc,
      icon: Search,
    },
    {
      title: t.step3Title,
      desc: t.step3Desc,
      icon: Newspaper,
    },
    {
      title: t.step4Title,
      desc: t.step4Desc,
      icon: CheckCircle2,
    },
  ];

  useEffect(() => {
    if (!isLoading) return;

    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev < steps.length - 1 ? prev + 1 : prev));
    }, 2400);

    return () => {
      clearInterval(interval);
    };
  }, [isLoading, steps.length]);

  if (!isLoading) return null;

  return (
    <div className="w-full bg-slate-900/90 border border-blue-500/30 rounded-2xl p-6 shadow-2xl backdrop-blur-sm animate-pulse-subtle">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
        <h3 className="text-sm font-bold text-cyan-300 tracking-wide uppercase">
          {t.pipelineTitle}
        </h3>
      </div>

      <div className="space-y-4">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          const isDone = idx < currentStep;
          const isCurrent = idx === currentStep;

          return (
            <div
              key={idx}
              className={`flex items-start gap-3.5 p-3 rounded-xl transition-all ${
                isCurrent
                  ? 'bg-blue-950/60 border border-blue-500/40 text-white'
                  : isDone
                  ? 'bg-slate-950/40 text-slate-300 border border-slate-800'
                  : 'text-slate-600 border border-transparent'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                  isCurrent
                    ? 'bg-blue-600 text-white animate-bounce'
                    : isDone
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-slate-800 text-slate-600'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4
                    className={`text-sm font-semibold ${
                      isCurrent ? 'text-blue-300' : isDone ? 'text-slate-200' : 'text-slate-500'
                    }`}
                  >
                    {step.title}
                  </h4>
                  {isCurrent && (
                    <span className="text-[11px] font-mono text-cyan-400 animate-pulse">
                      {t.processing}
                    </span>
                  )}
                  {isDone && (
                    <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                      {t.done}
                    </span>
                  )}
                </div>
                <p
                  className={`text-xs mt-0.5 leading-relaxed ${
                    isCurrent ? 'text-slate-300' : isDone ? 'text-slate-400' : 'text-slate-600'
                  }`}
                >
                  {step.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
