// components/VerificationResultView.tsx
'use client';

import React, { useState } from 'react';
import { VerificationResult } from '@/lib/types';
import { AppLanguage } from '@/lib/translations';
import { Download, ExternalLink, Loader2 } from 'lucide-react';

interface VerificationResultViewProps {
  result: VerificationResult;
  lang: AppLanguage;
}

export default function VerificationResultView({ result }: VerificationResultViewProps) {
  const [hasYellowBorder, setHasYellowBorder] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);

  const gallery = result.realMediaGallery || [];

  const handleDownloadAll = async () => {
    setIsDownloading(true);
    try {
      const items = gallery.map((item, i) => ({
        url: item.imageUrl,
        filename: `${String(i + 1).padStart(2, '0')}_${item.publisher}_Screen.svg`,
        title: item.title,
      }));

      const res = await fetch('/api/download-zip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items,
          folderName: `${result.publisher || 'News'}_Screenshots`,
        }),
      });

      if (!res.ok) throw new Error('Download failed');

      const blob = await res.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `Article_Screenshots_${gallery.length}items.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(downloadUrl);
    } catch {
      alert('ダウンロードに失敗しました。');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* ATTACHMENT HEADER BAR: 記事スクリーン一覧 (15件) + 太枠イエローボーダー + 全スクリーンをダウンロード */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-2">
        <h3 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center gap-2">
          <span>記事スクリーン一覧</span>
          <span className="text-slate-400 font-normal text-lg">({gallery.length}件)</span>
        </h3>

        <div className="flex items-center gap-4 self-start sm:self-auto">
          {/* Checkbox: 太枠イエローボーダー */}
          <label className="flex items-center gap-2 text-sm text-slate-300 font-semibold cursor-pointer select-none">
            <input
              type="checkbox"
              checked={hasYellowBorder}
              onChange={(e) => setHasYellowBorder(e.target.checked)}
              className="w-4 h-4 rounded border-amber-400 text-amber-400 focus:ring-amber-400 accent-amber-400 cursor-pointer"
            />
            <span className={hasYellowBorder ? 'text-amber-400' : 'text-slate-400'}>太枠イエローボーダー</span>
          </label>

          {/* Yellow Action Button: 全スクリーンをダウンロード */}
          <button
            onClick={handleDownloadAll}
            disabled={isDownloading || gallery.length === 0}
            className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-black text-sm flex items-center gap-2 shadow-lg shadow-amber-400/20 transition-all cursor-pointer disabled:opacity-50"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                <span>生成中...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>全スクリーンをダウンロード</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 3-COLUMN CARD GRID MATCHING ATTACHMENT */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {gallery.map((card, idx) => (
          <div
            key={card.id || idx}
            className={`w-full rounded-2xl overflow-hidden transition-all bg-white shadow-xl ${
              hasYellowBorder ? 'ring-6 ring-amber-400' : 'border border-slate-200'
            }`}
          >
            <div className="w-full relative">
              <img
                src={card.imageUrl}
                alt={card.title}
                className="w-full h-auto block"
              />
            </div>

            {/* Direct Open Article Action */}
            <div className="p-3 bg-white border-t border-slate-100 flex items-center justify-between">
              <a
                href={card.articleUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-bold text-slate-700 hover:text-blue-600 flex items-center gap-1.5 transition-colors"
              >
                <span>元記事を開く</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href={card.imageUrl}
                download={`${card.publisher}_Screen_${idx + 1}.svg`}
                className="text-xs font-semibold text-amber-600 hover:text-amber-500 flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>単体保存</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}